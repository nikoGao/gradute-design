/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: file.c,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#include "file.h"
#include "CF.h"
#include "FAT32.h"
#include "usb_debug.h"

static FILE file;	//static allocation.. should be made dynamic when multiple file support required.


//-----------------------------------------------------------------------------
//Counts the number of sub directories in given file path
//NOTE: the path given must be a directory path and not a file path.
//It must not end with '\' or a filename.
//a path of c:\songs\sting\brand new	returns a value 3 since there are
//3 directories in the path.
int GetTotalDirLevelsInPath(const char *path)
{
	int levels=0;

	// Count levels in path string
	while(*path != 0)
	{
		// If slash detected escape from for loop
		if (*path == '\\') 
		{ 
			// Increase number of subdirs founds
			levels++;
		}
		path++;
	}
	
	// Subtract the spurious last addition and return the value
	return levels;
}

  
//-----------------------------------------------------------------------------
// Full path of file is passed in FullPath string. 
// this function splits the full path of the file into directory path
// in Path and Filename in FileName.
//-----------------------------------------------------------------------------
void SplitFilePath(const char *FullPath, char *DirPath, char *FileName)
{
  const char *NameStart;
  const char *s;

  // Move to end of FullPath  String
//  for (s = FullPath; *s != 0; s++);
  
  s = FullPath + strlen(FullPath);
  
  // Now move backward until '\' is found. The name starts after the '\' 
  for (; (*s != '\\') && (s != FullPath); s--);
  
  if (*s == '\\') 
  	s++;	//now 's' points to start of filename
  	
  // Copy the filename to FileName
  for (NameStart = s; (*FileName++ = *s++); );
  
  
  // Finally we copy the portion of FullPath before the file name    
  // into Path, removing the non-root trailing backslash if present. 
  for (s = FullPath; s < NameStart; s++, DirPath++) 
  	*DirPath = *s;
  	
  //check if non root folder and then remove trailing backslash
  if ((NameStart > FullPath + 1) && (*(DirPath - 1) == '\\')) 
  	DirPath--;		//point to '\\'
  	
  *DirPath = 0;
}

//Takes the path string in 'Path' and folder level in 'level' as input 
//and returns the folder/directory string which is at that level
int GetDirStringFromPath(const char *pathStr, int levelreq, char *dirStr)
{
	int i;
	int pathlen=0;
	int levels=0;
	int copypnt=0;

	//check if invalid level i.e. equal to or below root level
	if(levelreq <= 0)
	{
		dirStr[0] = '\0';	//NULL terminate
		return	1;	//error
	}
	
	// Get string length of Path
	pathlen = strlen (pathStr);

	// Search through path to get the required level
	for (i = 0; i<pathlen; i++)
	{
		// If a '\' is found then increase level
		if (*pathStr=='\\') 
			levels++;

		//if in required level then copy the characters to folderStr
		if ( (levels==levelreq) && (*pathStr != '\\') ) 
			dirStr[copypnt++] = *pathStr;

		// Increment through path string
		*pathStr++;
	}

	// Null Terminate
	dirStr[copypnt] = '\0';

	// If a string was copied return 0 else return 1
	if (dirStr[0]!='\0') 
		return 0;	// Found
	else
		return 1;	// Not Found
}


//Removes spaces after extension or last word and stores the string in 'dest'
void RemoveTrailingSpaces(const char* source, char *dest)
{
	int i;
	int lastNonSpacePos;

	// Find total string length of source string
	lastNonSpacePos = strlen(source);

	// Find last position in string which is not a space
	while (lastNonSpacePos != 0)
	{
		if (source[--lastNonSpacePos] != ' ')
			break;
	}

	//if lastNonSpacePos == 0 means entire string was filled with space
	//or string was null.
	if(lastNonSpacePos == 0)
	{
		i = 0;	//to make dest a null string.
	}
	else
	{
		// Copy from beginning of string upto last nonspace character
		for (i = 0; i <= lastNonSpacePos; i++)
			dest[i]=source[i];
	}
	dest[i] = '\0';
}


int strcmpNocase(const char* str1, const char* str2)
{
	int len;
	char c1, c2;	
	len = strlen(str1);
	if(len != strlen(str2))
	{
		//lengths don't match
		return 1;	//not equal
	}
	
	while(len > 0)
	{
		c1 = *str1++;
		c2 = *str2++;
		
		if(c1 >= 'A' && c1 <= 'Z')
		{
			c1 += 'a' - 'A';
		}
		
		if(c2 >= 'A' && c2 <= 'Z')
		{
			c2 += 'a' - 'A';
		}		   
		
		if(c1 != c2)
		{
			//not equal
			return 1;
		}
		len--;
	}
	//equal
	return 0;
}
            
//Compare two filenames to see if they match
//NOTE: This function truncates the original strings if they have any 
//trailing spaces.
int CompareFileNames(char* name1, char* name2)
{
	// Crop both strings for any trailing spaces
	RemoveTrailingSpaces(name1, name1);	//destination same as source
	RemoveTrailingSpaces(name2, name2);	//destination same as source
	
	// Compare both strings and return 1 if they match
	if (strcmpNocase(name1, name2) != 0) 
	{
		return 1;	//filenames not equal
	}
	else
		return 0;	//filenames equal
}

//converts a packed SFN file name entry into a normal file name
void Get8_3Filename(char* sfn, char* filename)
{
	int i,j, extEnd;

	char tempSfnName[13];	//8 name, 1 for ., 3 for extension, 1 for null
	
	//get first no space in filename backwards
	for(i=7; i>=0; i--)
	{
		if(sfn[i] != ' ')
			break;
	}
	i++;	//now i points to space
	
	//get first no space in extension backwards
	for(j=10; j>=8; j--)
	{
		if(sfn[j] != ' ')
			break;
	}
	
	extEnd = j;	

	//copy valid filename
	for(j=0; j<i; j++)
	{
		tempSfnName[j] = sfn[j];
	}	
	
	if(extEnd < 8)
	{
		//no extension
		tempSfnName[j] = 0;
	}
	else
	{
		tempSfnName[j++] = '.';
		//copy valid extension
		
		for(i=8; i<=extEnd; j++, i++)
		{
			tempSfnName[j] = sfn[i];
		}
		tempSfnName[j] = 0;
	}

	//now copy tempSfnName to filename
	strcpy(filename, tempSfnName);
}

//opens a file handle from a given cluster number
FILE *fopen_cluster(UI32 startCluster)
{
	FILE *fp;

	fp = &file;
	
	fp->feof = 0;	//mark not end of file
	fp->startCluster = startCluster;
	fp->currentCluster = startCluster;	
	
	fp->feof = 0;	//mark not end of file
	fp->currentSectorInCluster = 0;	//1st sector in cluster
	fp->byteNum = 0;	//1st byte

	return fp;	
}

static UI16 dirBuffer[256];	//512 bytes...used for directory/file browsing

//obtains the filename of the file which is at a given offset in the given directory path
//obtained filename is in 8.3 format
//file offset depends upon the location of the file in the FAT.
//returns 0 if success and 1 if error
int GetFilenameInDirectory(char *directoryPath, int fileOffset, char *filename)
{
	FILE fDir;
	int recordIdx = 0;
	UI16* recordPtr;
	UI8 attribute;
	int i;
	UI32 dirCluster;
	int done = 0;
	int fileCount = 0;
	DIR_ENTRY dirEntry;

	dirCluster = fopen_DIR(directoryPath);

	fDir.feof = 0;	//mark not end of file
	fDir.startCluster = dirCluster;
	fDir.currentCluster = dirCluster;	
	fDir.currentSectorInCluster = 0;	//1st sector in cluster
	fDir.byteNum = 0;	//1st byte
	fDir.fileSize = 0xFFFFFFFF;	//set max. possible size

	while(1)
	{
		if(fread_sector(&fDir, dirBuffer, &i) != 0)
		{       
			usb_print_str("GetFilenameInDir(): fread error or EOF");
			//Either EOF or error
			return -2;
		}
		//start searching in the sector for the given directory entry	
		//there are 16 FAT32 records (32 bytes) in 1 sector (512 bytes)
		for(recordIdx = 0; recordIdx < 16; recordIdx++)
		{
			//get pointer to 1 FAT32 record at recordIdx
			recordPtr = &dirBuffer[recordIdx*16];	//*16 since 1 record is 32 bytes (i.e. 16 words)
			
			switch(Get8BitWord(recordPtr, 0))
			{
				case 0:
					//directory ended
					return 1;	//file not found

				case 0xE5:                  
					//directory entry is free so skip this entry and go to next
					continue;	//continue for loop next iteration.
				
				//can add invalid name checks here.
				
				default:
					//found a FAT32 record.. check if it is a valid entry
					//get attribute byte
					attribute = Get8BitWord(recordPtr, 11);
					
					if(attribute & ATTR_VOLID)
					{
						//volume ID so ignore
					}
					else
					{   
						//This is a Short name entry
						GetDirEntryFromBuffer(recordPtr, &dirEntry);

						//check if it is a file entry
						if( (dirEntry.Attr & ATTR_DIR) == 0)
						{
							//it is a file
//							Get8_3Filename((char *)dirEntry.Name, (char *)dirEntry.Name);
							if(fileCount == fileOffset)
							{
								//found the file at given offset
								//obtain the 8.3 filename
								Get8_3Filename((char *)dirEntry.Name, filename);
								return 0;	//success
							}
							fileCount++;
						}
   
					}
			}//end switch

		}//end for

	}//end while

}

//returns the number of files in given directory path
//returns negative value if error
int GetTotalFilesInDirectory(char *directoryPath)
{
	FILE fDir;
	int recordIdx = 0;
	UI16* recordPtr;
	UI8 attribute;
	int i;
	UI32 dirCluster;
	int done = 0;
	int fileCount = 0;
	DIR_ENTRY dirEntry;

	dirCluster = fopen_DIR(directoryPath);
	usb_print_long(dirCluster);

	fDir.feof = 0;	//mark not end of file
	fDir.startCluster = dirCluster;
	fDir.currentCluster = dirCluster;	
	fDir.currentSectorInCluster = 0;	//1st sector in cluster
	fDir.byteNum = 0;	//1st byte
	fDir.fileSize = 0xFFFFFFFF;	//set max. possible size

	while(1)
	{
		i = fread_sector(&fDir, dirBuffer, &i);
		if(i == -2)
		{       
			usb_print_str("GetTotalFilesInDir(): fread error");
			//error
			return -1;
		}
		else if(i == -1)
		{
			//directory ended so return number of files counted.
			return fileCount;
		}
		//start searching in the sector for the given directory entry	
		//there are 16 FAT32 records (32 bytes) in 1 sector (512 bytes)
		for(recordIdx = 0; recordIdx < 16; recordIdx++)
		{
			//get pointer to 1 FAT32 record at recordIdx
			recordPtr = &dirBuffer[recordIdx*16];	//*16 since 1 record is 32 bytes (i.e. 16 words)
			
			switch(Get8BitWord(recordPtr, 0))
			{
				case 0:
					//directory ended
					done = 1;
					break;

				case 0xE5:                  
					//directory entry is free so skip this entry and go to next
					continue;	//continue for loop next iteration.
				
				//can add invalid name checks here.
				
				default:
					//found a FAT32 record.. check if it is a valid entry
					//get attribute byte
					attribute = Get8BitWord(recordPtr, 11);
					
					if(attribute & ATTR_VOLID)
					{
						//volume ID so ignore
					}
					else
					{   
						//This is a Short name entry
						GetDirEntryFromBuffer(recordPtr, &dirEntry);

						//check if it is a file entry
						if( (dirEntry.Attr & ATTR_DIR) == 0)
						{
							//it is a file
//							Get8_3Filename((char *)dirEntry.Name, (char *)dirEntry.Name);
							fileCount++;
						}
   
					}
			}//end switch

			if(done == 1)
			{
				break;
			}

		}//end for

		if(done == 1)
		{
			break;
		}

	}//end while

	return fileCount;
}
 
#define MAX_LFN_LENGTH 100  //including null
#define MAX_LFN_ENTRIES (MAX_LFN_LENGTH/13 + 1)
char lfnCache[MAX_LFN_ENTRIES][13];
char lfnString[MAX_LFN_LENGTH];
int lfnStrings = 0;
int lfnIndex = 0;
int lfnCount = 0;

//searches the given directory for the given file/directory name
//and returns the FAT32 record of the file/directory if a match is found
//returns non zero if sub directory/file of given name was not found
int GetMatchingRecord(UI32 dirCluster, char* nameToFind, DIR_ENTRY *pDirEntry)
{
	FILE fDir;
	int recordIdx = 0;
	UI16* recordPtr;
	UI8 attribute;
	int i;
/*	
	fpDir = fopen_cluster(dirCluster);	
	
	if(fpDir == 0)
		return -1;	//error could not open file
*/
	fDir.feof = 0;	//mark not end of file
	fDir.startCluster = dirCluster;
	fDir.currentCluster = dirCluster;	
	fDir.currentSectorInCluster = 0;	//1st sector in cluster
	fDir.byteNum = 0;	//1st byte
	fDir.fileSize = 0xFFFFFFFF;	//set max. possible size

	lfnStrings = 0;	//clear LFN cache
			
	while(1)
	{
		if(fread_sector(&fDir, dirBuffer, &i) != 0)
		{       
			usb_print_str("fread error or EOF");
			//Either EOF or error
			return -2;
		}
		//start searching in the sector for the given directory entry	
		//there are 16 FAT32 records (32 bytes) in 1 sector (512 bytes)
		for(recordIdx = 0; recordIdx < 16; recordIdx++)
		{
			//get pointer to 1 FAT32 record at recordIdx
			recordPtr = &dirBuffer[recordIdx*16];	//*16 since 1 record is 32 bytes (i.e. 16 words)
			
			switch(Get8BitWord(recordPtr, 0))
			{
				case 0:
					usb_print_str("directory ended");
					//directory ended, stop searching
					return -3;

				case 0xE5:                  
					usb_print_str("free entry");
					//directory entry is free so skip this entry and go to next
					lfnStrings = 0;	//clear LFN cache
					continue;	//continue for loop next iteration.
				
				//can add invalid name checks here.
				
				default:
					//found a FAT32 record.. check if it is a valid entry
					//get attribute byte
					attribute = Get8BitWord(recordPtr, 11);
					
					if( (attribute & ATTR_LFN_MSK) == ATTR_LFN)
					{
						//long name entry.
						usb_print_str("got lfn");						
						//get index
						lfnIndex = Get8BitWord(recordPtr, 0);
						//check if last index 
						usb_print_int(lfnIndex);
						if(lfnIndex & 0x40)
						{
							lfnIndex &= ~0xC0;	//remove unused bits and end flag to get index.
							lfnStrings = lfnIndex;
							usb_print_int(lfnStrings);
						}
						lfnIndex--;	//convert to 0 offset
						//check if fits in our LFN cache
						if(lfnIndex < MAX_LFN_ENTRIES)
						{
							lfnCache[lfnIndex][0] = Get8BitWord(recordPtr, 1);
							lfnCache[lfnIndex][1] = Get8BitWord(recordPtr, 3);
							lfnCache[lfnIndex][2] = Get8BitWord(recordPtr, 5);
							lfnCache[lfnIndex][3] = Get8BitWord(recordPtr, 7);
							lfnCache[lfnIndex][4] = Get8BitWord(recordPtr, 9);
							lfnCache[lfnIndex][5] = Get8BitWord(recordPtr, 14);
							lfnCache[lfnIndex][6] = Get8BitWord(recordPtr, 16);
							lfnCache[lfnIndex][7] = Get8BitWord(recordPtr, 18);
							lfnCache[lfnIndex][8] = Get8BitWord(recordPtr, 20);
							lfnCache[lfnIndex][9] = Get8BitWord(recordPtr, 22);
							lfnCache[lfnIndex][10] = Get8BitWord(recordPtr, 24);
							lfnCache[lfnIndex][11] = Get8BitWord(recordPtr, 28);
							lfnCache[lfnIndex][12] = Get8BitWord(recordPtr, 30);
						}
					}
					else if(attribute & ATTR_VOLID)
					{
						//volume ID so ignore
						lfnStrings = 0;	//clear LFN cache						
					}
					else
					{   
						GetDirEntryFromBuffer(recordPtr, pDirEntry);					
						//This is a Short name entry
							//if file entry (i.e. SFN) then convert 8.3 packed name to normal filename
						if( (pDirEntry->Attr & ATTR_DIR) == 0)
						{
							//it is a file
							Get8_3Filename((char *)pDirEntry->Name, (char *)pDirEntry->Name);
						}
						usb_print_str((char *)pDirEntry->Name);
						usb_print_str(nameToFind);
						//check if the given name matches the name in record
						if(CompareFileNames((char *)pDirEntry->Name, nameToFind) == 0)
						{
							//found a matching entry...save it in output argument
							usb_print_str("sfn match");
							return 0;
						}
						if(lfnStrings != 0)
						{
							usb_print_str("lfn + sfn");
							//we have a cached LFN
							//so compare long file names
							//copy LFN from cache to string
							lfnCount = 0;
							for(lfnIndex=0; lfnIndex<lfnStrings; lfnIndex++)
							{
								for(i=0; i<13; i++)
								{
									if(lfnCount < MAX_LFN_LENGTH)
									{
										lfnString[lfnCount++] = lfnCache[lfnIndex][i];
									}
									else
									{
//										usb_print_str("max LFN limit reached");
										break;
									}
								}
							}
							lfnString[lfnCount] = 0;	//null terminate
							usb_print_str(lfnString);
							usb_print_str(nameToFind);
							//check if the given name matches the name in record
							if(CompareFileNames((char*)lfnString, nameToFind) == 0)
							{
								//found a matching entry...save it in output argument
								usb_print_str("lfn match");
								return 0;
							}
						}
/*
						else
						{   
							usb_print_str("sfn only");
							//we have SFN only
							//got a normal entry

							//if file entry (i.e. SFN) then convert 8.3 packed name to normal filename
							if( (pDirEntry->Attr & ATTR_DIR) == 0)
							{
								//it is a file
								Get8_3Filename((char *)pDirEntry->Name, (char *)pDirEntry->Name);
							}
							usb_print_str(pDirEntry->Name);
							usb_print_str(nameToFind);
							//check if the given name matches the name in record
							if(CompareFileNames((char*)pDirEntry->Name, nameToFind) == 0)
							{
								//found a matching entry...save it in output argument
								usb_print_str("sfn match");
								return 0;
							}
						}   
*/
						lfnStrings = 0;	//clear LFN cache
					}
			}
		}
	}
}


//returns the start cluster of the last subfolder in the given path
//dirPath is a path to the directory. it must not contain a trailing '\'.
//returns 0xFFFFFFFF if directory could not be opened
//not tested
UI32 fopen_DIR(char* dirPath)
{
	static char nextDirName[32];	//for containing name for 1 directory
	int maxDirLevels;
	int level;
	UI32 curDirCluster;
	DIR_ENTRY nextDirEntry;
	
	//get number of directory levels in path
	maxDirLevels = GetTotalDirLevelsInPath(dirPath);	
	
	//start from root level 
	curDirCluster = FAT32.root_begin_cluster;
	
	//if root level then we don't need to search
	if(maxDirLevels <= 1)    
	{
		return curDirCluster;
	}

	for(level = 1; level <= maxDirLevels; level++)
	{
		//get name of next sub directory
		GetDirStringFromPath(dirPath, level, nextDirName);
		
		//search the name in current directory
		if(GetMatchingRecord(curDirCluster, nextDirName, &nextDirEntry) != 0)
		{
			//did not find matching name so exit
			return 0xFFFFFFFF;
		}
		else
		{
			//found a matching record
			//get start cluster of next sub directory
			curDirCluster = nextDirEntry.FirstCluster;
		}
	}
	
	//found a matching record
	return curDirCluster;
}


//opens a file handle to the file in the given path.
//NOTE: Multiple file open not yet supported.
//mode
FILE *fopen(char* fullPath)
{
//	static char dirPath[260];	//see FATgen103.pdf pg.29
	static char dirPath[100];	//see FATgen103.pdf pg.29
	static char fileName[32];	//should be 255.
	UI32 dirCluster;
	DIR_ENTRY dirEntry;

	FILE *fp;
	
	fp = &file;
/*	
	//allocate FILE structure on heap and make a file pointer point to it.
	//NOTE: malloc does not work try using MEM_alloc
	//and use MEM_free in fclose();
	FILE *fp = (FILE *)malloc(sizeof(FILE));
	if(fp == 0)
	{
		//insufficient memory on heap
		return fp;
	}
*/	
	fp->feof = 0;	//mark not end of file
	fp->currentSectorInCluster = 0;	//1st sector in cluster
	fp->byteNum = 0;	//1st byte
	
	//split full path to path and filename
	SplitFilePath(fullPath, dirPath, fileName);

	//Get the last sub directory start cluster
	dirCluster = fopen_DIR(dirPath);
	if(dirCluster == 0xFFFFFFFF)
	{
		//could not open directory
		return 0;
	}
	else
	{
		usb_print_str("directory opened");
		usb_print_str(fileName);
		//Get to file record of the required file from the directory
		if(GetMatchingRecord(dirCluster, fileName, &dirEntry) != 0)
		{
			//did not find the required file
			return 0;
		}
		else
		{
			//update file pointer members	
			fp->startCluster = dirEntry.FirstCluster;
			fp->currentCluster = dirEntry.FirstCluster;
			fp->fileSize = dirEntry.FileSize;
		}
	}
	
	return fp;
}

//reads next sector from the file stream into the given buffer.
int fread_sector(FILE *fp, void* buffer, int* pBytesRead)
{
	  UI32 LBAtoRead;

	  if(fp->feof)
	  {
	  	return -1;	//already end of file.
	  }
	  
	  // Get LBA of sector to read = cluster start LBA address + sector offset
	  LBAtoRead = FAT32_GetStartLBAofCluster(fp->currentCluster) + fp->currentSectorInCluster;
	  
	  //increment sector
	  fp->currentSectorInCluster++;
	  *pBytesRead = 512;	//will change it if last sector of file.
	  
	  if(fp->currentSectorInCluster == FAT32.sectors_per_cluster)
	  {
	  	//all sectors in current cluster exhausted.. find next cluster
	  	
	  	//reset parameters
	  	fp->currentSectorInCluster = 0;
	  	//find next cluster
	  	fp->currentCluster = FAT32_FindNextCluster(fp->currentCluster);
	  	if(fp->currentCluster == 0xFFFFFFFF)
	  	{
	  		//got end of file
	  		fp->feof = 1;	//mark EOF flag
	  		//bytesRead will be <= 512
	  		*pBytesRead = fp->fileSize - fp->byteNum;
	  	}
	  }	  
	  
	  //read the sector into buffer
	  if(CF_ReadSector(LBAtoRead, buffer))
	  	return -2;	//error reading sector
	  else
	  {
	  	fp->byteNum += *pBytesRead;
	  	return 0;	//success
	  }
}

#define NUM_SECTORS_TO_BUFFER	8	//must be power of 2

static int sectorCount = 0;

//reads next sector from the file stream into the given buffer.
//Reading 1 sector everytime using CF_ReadSector() takes more time since
//each time a command is issued to the CF card and then data is read.
//Instead we can use CF_ReadSectors() where command is issued once and multiple
//sectors can be read without delay.
//This function wisely uses this technique and executes a CF_ReadSectors() command
//so that upto NUM_SECTORS_TO_BUFFER consecutive sectors can be read.
//This function determines how many sectors are consecutive and reads that many
//sectors (actually it prepares to read that many sectors by using CF_ReadSectors())
//The sectors are read when required only, so no additional RAM is required.
//Application must simply call fast_fread_sector() and not worry about buffering.

//********************<<IMPORTANT>>*********************************************
//NOTE: once fast_fread_sector() is called no other file function must be used
//until fast_fread_sector_terminate() is called.
//******************************************************************************

int fast_fread_sector(FILE *fp, void* buffer, int* pBytesRead)
{

	UI32 LBAtoRead;
	UI32 nextCluster;
	UI32 diff;
	int i;

	if(fp->feof)
	{
	 	return -1;	//already end of file.
	}

	if(sectorCount == 0)
	{
		// Get LBA of sector to read = cluster start LBA address + sector offset
	  	LBAtoRead = FAT32_GetStartLBAofCluster(fp->currentCluster);

		sectorCount = FAT32.sectors_per_cluster;	  	
		
	  	if(sectorCount >= NUM_SECTORS_TO_BUFFER)
	  	{
	  		//we can easily buffer all those sectors since they all are in line
	  		
		  	//find next cluster
		  	fp->currentCluster = FAT32_FindNextCluster(fp->currentCluster);
		}
		else
		{
			//sectors per cluster can be either 1, 2, 4 ... upto NUM_SECTORS_TO_BUFFER

			//so we will determine how many clusters are inline and prepare
			//to read those many at a stretch                             
			//NOTE: sectors in a cluster are always inline.
			//we can read in one stretch only those clusters which are in line
			//e.g. cluster numbers 4, 5, 6, 7 are inline.
			
			for(i = sectorCount; i < NUM_SECTORS_TO_BUFFER ; i += sectorCount)
			{                                 
	  			nextCluster = FAT32_FindNextCluster(fp->currentCluster);
	  			diff = nextCluster - fp->currentCluster;
  				fp->currentCluster = nextCluster;

		  		if(fp->currentCluster == 0xFFFFFFFF)
		  		{
	  				//this was the last cluster of file.
					//can't mark EOF here since this may not be the last sector.
	  				break;
		  		}  		
		  					  				
  				if(diff != 1)
  				{
  					//cluster chain not in line at this point
  					break;
  				}
  			}
  			sectorCount = i;	//number of sectors in line that can be read in 1 stretch  			
  			//find out next cluster for next fread
			fp->currentCluster = FAT32_FindNextCluster(fp->currentCluster);
	  	}   
	  	
		if(CF_ReadSectors(LBAtoRead, sectorCount))
		{
		  	return -2;	//error
		}
		read_sector(DATA_REG, buffer);
		sectorCount--;
    }
    else
    {
	   	read_sector(DATA_REG, buffer);
	   	sectorCount--;
	}


	//check if end of file reached.
	
	//get number of bytes left to read from file
	diff = fp->fileSize - fp->byteNum;
	if(diff <= 512)     
	{                          
		//this was the last sector of file
		*pBytesRead = diff;
		fp->feof = 1;
	}
	else
		*pBytesRead = 512;
    
    //increment byte count of file.
	fp->byteNum += *pBytesRead;	
  	return 0;
}
 
//This function must be called after fast_fread_sector() is used and
//before using any other file function. It reads out any pending sectors
//from CF card and prepares it for the next command.
void fast_fread_terminate()
{    
	//read out any pending sectors from CF card, so that it is ready for next command
	while(sectorCount > 0)
	{                 
		read_sector(DATA_REG, cf_buffer.data);
		sectorCount--;
	}
}

//closes the file handle and frees all resources.
void fclose(FILE *fp)
{
/*
	free(fp);	//use MEM_free instead.
*/	
	fp = 0;
}
