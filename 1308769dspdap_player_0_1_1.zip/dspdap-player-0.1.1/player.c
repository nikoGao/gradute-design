/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: player.c,v 1.3 2007/06/06 12:04:05 Roger Exp $
 */

#include <std.h>
#include <gio.h>
#include <csl.h>
#include <hwi.h>
#include <csl_usb.h>
#include <csl_pwr.h>
#include <csl_gpio.h>
#include <c5509_usb.h>

#include "mad.h"
#include "playercfg.h"
#include "file.h"
#include "player.h"
#include "system_io.h"
#include "usb_debug.h"
#include "usb_task.h"

static PLAYER gPlayer;


//initializes the player structure for the root directory
int PlayerInit(PLAYER *pPlayer)
{
	int i;

	strcpy(pPlayer->directory, "\\");	//set player directory to root

	pPlayer->totalFiles = GetTotalFilesInDirectory(pPlayer->directory);

	if(pPlayer->totalFiles < 0)
	{
		//there was an error in GetTotalFilesInDirectory()
		pPlayer->totalFiles = 0;
		return 1;	//error
	}

	//build file index list
	//here we decide if we want alphabetical order, random order
	//or as per order in FAT

	//for now we use order in FAT
	for(i=0; i < pPlayer->totalFiles ; i++)
	{
		pPlayer->fileIdxList[i] = i;
	}

	//select 1st file to play
	pPlayer->fileIdx = 0;
	pPlayer->state = STOPPED;
	pPlayer->volume = PLAYER_VOLUME_DEFAULT;	//set player volume to default level
	AIC_setHPVolume(pPlayer->volume);	//set AIC volume
	return 0;
}

//opens the current/next eligible file to play
int PlayerStartPlay(PLAYER *pPlayer)
{
	char filename[13];	//8.3 format only
	char fullpath[30];
	int i;

	//get filename from file index
	GetFilenameInDirectory(pPlayer->directory, pPlayer->fileIdxList[pPlayer->fileIdx], filename);	
	usb_print_str(filename);
	i = strlen(filename);	//i = null char position
	i -= 3;				//i = file extension position
	//check if MP3 file from extension
	if( (filename[i] == 'M') && (filename[i+1] == 'P') && (filename[i+2] == '3') )
	{
		//yes. extension is MP3

		//form full file path
		strcpy(fullpath, pPlayer->directory);
		strcpy(fullpath, filename);
		usb_print_str(fullpath);
		pPlayer->fp = fopen(fullpath);
		if(pPlayer->fp)
		{
			//file opened
			return 0;	//success
		}
		else
		{
			return 1;	//error.. could not open file
		}
	}
	else
	{
		//un-supported file
		return 2;	//error.. un-supported file
	}
}

//gets the filename of the next audio file to be played
int GetNextAudioFile(PLAYER *pPlayer)
{
	int trys;

	trys = 0;

	while(1)
	{
		//get next file index
		pPlayer->fileIdx++;
		if(pPlayer->fileIdx > pPlayer->totalFiles)
		{
			pPlayer->fileIdx = 0;
		}

		//check if all files parsed
		if(trys >= pPlayer->totalFiles)
		{
			//went across all files in current folder but could not play any
			//because none of them were supported
			return 1;
		}

		//try to start playing the file
		if(PlayerStartPlay(pPlayer) == 0)
		{
			//succeeded
			return 0;
		}
		trys++;
	}
}

//gets the filename of the previous audio file to be played
int GetPreviousAudioFile(PLAYER *pPlayer)
{
	int trys;

	trys = 0;

	while(1)
	{
		//get previous file index
		if(pPlayer->fileIdx <= 0)
		{
			pPlayer->fileIdx = pPlayer->totalFiles;
		}
		else
		{
			pPlayer->fileIdx--;
		}

		//check if all files parsed
		if(trys >= pPlayer->totalFiles)
		{
			//went across all files in current folder but could not play any
			//because none of them were supported
			return 1;
		}

		//try to start playing the file
		if(PlayerStartPlay(pPlayer) == 0)
		{
			//succeeded
			return 0;
		}
		trys++;
	}
}


#define CHUNK_SIZE 32	/*pcm samples*/

//player task
void PlayerTask()
{
	Int key_id;
    int i;
	int *bufPtr;
	int bufSize;    

#ifdef WAVE_DEBUG
	UI16 header[22];
	PCM_SAMPLE chunk[CHUNK_SIZE];
	PCM_SAMPLE *pcm_ptr=0;
	PCM_SAMPLE *chunk_ptr;
	int size=0, pcm_left=0;
#endif

#ifdef USB_DEBUG
	C5509_USB_StateInfo info;
    C5509_USB_AppCallback deviceConnectCb = {
        (C5509_USB_TappCallback)SEM_post,
        &usbDeviceConnect   // semaphore to post when connected
    };

    // create bulk type dsp input channel for USB OUT(from host) endpoint #2
    readChan = GIO_create( "/udevUsb2", IOM_INPUT, NULL, NULL, NULL);

    if (readChan == NULL) {
        SYS_abort("Create input channel FAILED.");
    }
     
    // create bulk type dsp output channel for USB IN(to host) endpoint #2 
    writeChan = GIO_create( "/udevUsb2", IOM_OUTPUT, NULL, NULL, NULL);
    
    if (writeChan == NULL ) {
        SYS_abort("Create output channel FAILED.");
    }

    
    // Connect the device to the host.
    //  The deviceConnectCb Fxn(SEM_post) will get called with arg(sem handle)
    //  when connection is made(host enumerated bus) or immediately called if
    //  bus is already connected.
    // 
    GIO_control(readChan, C5509_USB_DEVICECONNECT, &deviceConnectCb);
    
    SEM_pend(&usbDeviceConnect, SYS_FOREVER);	// block until bus is connected

    GIO_control(readChan, C5509_USB_GETSTATEINFO, &info);
    
	usbConnected = 1;
#endif
	
	DMA_start(hDma4);	//start DMA transfer
	MCBSP_FSETH(hMcbsp0, SPCR2, XRST, 1); //turn on transmitter	

	usb_print_str("DSPdap - Digital Audio Player");

	usb_print_str("ISTR =");
	i = _ISTR;
	usb_print_int(i);

	if(FAT32_GetFAT32Details())
	{
		usb_print_str("GetFAT32Details() failed");
		while(1);
	}
	
	usb_print_str("Got FAT32 details");


	if(PlayerInit(&gPlayer))
	{
		usb_print_str("player init error");
		while(1);
	}

	usb_print_str("player init done");
	gPlayer.fileIdx = -1;
	if(GetNextAudioFile(&gPlayer))
	{
		usb_print_str("No supported files in directory");
		gPlayer.state = STOPPED;
	}
	else
	{
		gPlayer.state = PLAYING;
	}

#ifdef WAVE_DEBUG
	/*send the WAVE header*/
	//Chunk ID = RIFF
	header[0] = 'I'<<8 | 'R';
	header[1] = 'F'<<8 | 'F';

	//size = -1 = unknown
	header[2] = 0xFFFF;
	header[3] = 0xFFFF;

	//RIFF type = WAVE
	header[4] = 'A'<<8 | 'W';
	header[5] = 'E'<<8 | 'V';

	//wave chunks...

	//chunk ID = "fmt "
	header[6] = 'm'<<8 | 'f';
	header[7] = ' '<<8 | 't';

	//size = 16
	*(UI32 *)(header + 9) = 16;

	//compression = PCM = 1
	header[10] = 0x0001;
	//channels = 2
	header[11] = 0x0002;

	//sample rate = 44100 = 0xAC44
	*(UI32 *)(header + 13) = 44100;

	//bytes per sec = 44100 * no of channels * bytes per sample
	*(UI32 *)(header + 15) = 44100 * 2 * sizeof(PCM_SAMPLE)*2;

	//block align = 4
	header[16] = 4;
	//bits per sample = 16 = 0x10
	header[17] = sizeof(PCM_SAMPLE)*16;

	//data chunk...

	//chunk id = "data"
	header[18] = 'a'<<8 | 'd';
	header[19] = 'a'<<8 | 't';

	//chunk size = -1 = unknown
	header[20] = 0xFFFF;
	header[21] = 0xFFFF;

	//data samples.... 16-bit, L,R,L,R interleaved

	//dump the WAVE header
	usb_dump_wave(header, 22);
#endif

	while(1)
	{           

		if(MBX_pend(&MBX_keys, &key_id, 0))
		{
			//got a keypress message
			switch(key_id)
			{
				case KEY_BATT_LOW:
				//prepare to turn off player
					HWI_disable();		//disable all interrupts
					LED_on();
					AIC_setHPVolume(0);	//MUTE headphones;
					DMA_start(hDma4);	//stop DMA transfer
					MCBSP_FSETH(hMcbsp0, SPCR2, XRST, 0); //turn off transmitter	
					PWR_FSET(ICR, CLKGENI, 1);
					PWR_FSET(ICR, CPUI, 1);
					//shut down power by configuring PGOOD line as o/p and forcing it low
//					GPIO_pinDirection(IO_PGOOD, GPIO_OUTPUT);
//					GPIO_pinWrite(IO_PGOOD, 0);	//force PGOOD low
					asm("	IDLE");
					while(1);
					break;
				case KEY_VOL_UP:
					usb_print_str("VOL+");
					gPlayer.volume += PLAYER_VOLUME_DELTA;
					if(gPlayer.volume > PLAYER_VOLUME_MAX)
					{
						gPlayer.volume = PLAYER_VOLUME_MAX;
					}
					usb_print_int(gPlayer.volume);
					AIC_setHPVolume(gPlayer.volume);
					break;

				case KEY_VOL_DOWN:
					usb_print_str("VOL-");
					gPlayer.volume -= PLAYER_VOLUME_DELTA;
					if(gPlayer.volume < PLAYER_VOLUME_MIN)
					{
						gPlayer.volume = PLAYER_VOLUME_MIN;
					}
					usb_print_int(gPlayer.volume);
					AIC_setHPVolume(gPlayer.volume);
					break;

				case KEY_NEXT:
					usb_print_str("NEXT");
					GetNextAudioFile(&gPlayer);
					break;

			}
		}
	

//--------------stream the current file------------------
		if(gPlayer.state == PLAYING)
		{
			if(gPlayer.fp->feof)
			{
				usb_print_str("End of file reached");
				//try next file
				GetNextAudioFile(&gPlayer);
			}
			if(PIP_getWriterNumFrames(&input_pipe) > 0)
			{
				//there is a frame empty in i/p pipe and needs to be filled
				PIP_alloc(&input_pipe);
				
				bufPtr = (int *)PIP_getWriterAddr(&input_pipe);
				bufSize = PIP_getWriterSize(&input_pipe);

				if(bufSize < 256)
				{
					usb_print_str("Input pipe should be at least 256 words");
				}

				//read a sector from file into pipe
				if(fread_sector(gPlayer.fp, bufPtr, &i))
				{
					//error
					usb_print_str("fread error");
					while(1);
				}
					
				//pipe frame filled so pack it up
				PIP_put(&input_pipe);
			}

#ifdef WAVE_DEBUG
			/*dump output PCM samples to USB*/

			//see if new samples are available
			if(PIP_getReaderNumFrames(&output_pipe) == 0)
			{
				//no full frame to read
				SWI_post(&SWI_decode); //ensure decoder is running
			}
			else
			{	//there is a full frame in output_pipe
				PIP_get(&output_pipe);
				pcm_ptr = (PCM_SAMPLE *)PIP_getReaderAddr(&output_pipe);
			    //now pcm_ptr points to a buffer containing 576 stereo (32-bit) samples.			
			    
				size = PIP_getReaderSize(&output_pipe);//now size contains number of words

				pcm_left = size/sizeof(PCM_SAMPLE);	//now pcm_left contains number PCM_SAMPLES.
			
				while(pcm_left > 0)
				{
					//rearrange to L,R interleaved format
					chunk_ptr = chunk;
					for(i=0; i<CHUNK_SIZE/2; i++)
					{
#if PCM_PRECISION > 16
						/* we need to swap the words to match intel endianness */
						*chunk_ptr++ = (pcm_ptr[0]>>16 & 0xFFFF) | (pcm_ptr[0]<<16 & 0xFFFF0000);
						*chunk_ptr++ = (pcm_ptr[576]>>16 & 0xFFFF) | (pcm_ptr[576]<<16 & 0xFFFF0000);
#else
						*chunk_ptr++ = (*pcm_ptr);
						*chunk_ptr++ = (*(pcm_ptr+576));
#endif
						pcm_ptr++;
					}
					pcm_left -= CHUNK_SIZE;
				
					usb_dump_wave(chunk, CHUNK_SIZE*sizeof(PCM_SAMPLE));

				}

				//return frame to o/p pool
				PIP_free(&output_pipe);
			}
#endif
		/* else output_pipe is emptied in pcm_func by the AIC DMA */
		}
//----------------------------------------------------------

	} //end while
}

