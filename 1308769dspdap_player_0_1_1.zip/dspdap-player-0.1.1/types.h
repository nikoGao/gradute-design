/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: types.h,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned char UI8;	//uses 16-bit on c5000
typedef signed char I8;	//uses 16-bit on c5000

typedef unsigned int UI16;
typedef signed int I16;

typedef unsigned long UI32;
typedef signed long I32;

typedef unsigned int UI;	//16-bit


#endif /*_TYPES_H_*/
