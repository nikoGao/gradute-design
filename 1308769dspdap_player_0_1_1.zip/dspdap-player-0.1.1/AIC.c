/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: AIC.c,v 1.2 2007/06/05 11:53:57 Roger Exp $
 */

#include <std.h>
#include <prd.h>
#include <swi.h>

#include "playercfg.h"
#include <csl.h>
#include <csl_mcbsp.h>
#include <csl_dma.h>
#include <csl_pwr.h>

#include "IO.h"
#include "mad.h"
#include "usb_debug.h"

#define HPVOLUME_ADDR 0x0580	//L+R simultaneous update + zero detect
								//need to OR it with 7 bit volume value and write to MCBSP

#define HPVOLUME 0x05F9	//left channel volume for 0dB simultaneous update

void AIC_write(Uint16 word)
{
	while(MCBSP_xrdy(hMcbsp1) == 0); //wait till TX ready
	MCBSP_write16(hMcbsp1,word);			
}   

void DAC_write(Uint16 word)
{
	while(MCBSP_xrdy(hMcbsp0)==0); //wait till TX ready
	MCBSP_write16(hMcbsp0,word);
}


void AIC_init()
{
	//turn ON Mcbsp1 sample rate generator
	MCBSP_FSETH(hMcbsp1, SPCR2, GRST, 1);
	
	//turn ON Mcbsp1 transmitter
	MCBSP_FSETH(hMcbsp1, SPCR2, XRST, 1);
	
	AIC_write(0x1e00);		//reset all AIC registers to default values
	
	AIC_write(0x0812);      //DAC selected, bypass off, mic mute

	if(PCM_PRECISION > 16)
		AIC_write(0x0e5f);		//DAC master, DSP mode, 32 bits	
	else	
		AIC_write(0x0e53);		//DAC master, DSP mode, 16 bits

//	AIC_write(0x0e52);		//DAC master, I2S mode, 16 bits

	AIC_write(0x1023);	//44.1Khz
//	AIC_write(0x1019);	//32KHz
//	AIC_write(0x100d);	//8KHz
	
	AIC_write(0x1201);

//	AIC_write(HPVOLUME);	//set headphone volume to 0dB

	AIC_write(HPVOLUME - 22);	//-22dB
	
//	AIC_write(0x0572);	//set headphone volume to -27dB
						//disable zero cross detect.
//	AIC_write(0x0761);	//set headphone volume to -24dB
						//disable zero cross detect.
						
//	AIC_write(0x0a04);	//unmute DAC 44.1K de-emphasis
	AIC_write(0x0a00);	//unmute DAC no de-emphasis

	AIC_write(0x0c07);		//DAC on, mic off
}               


#define AIC_MIN_HP_VOL	0x30	//-73 dB..see AIC23 datasheet
#define AIC_MAX_HP_VOL	0x7F	//+6 dB..see AIC23 datasheet

//sets the headphone volume for the AIC23 Codec
//volume should be in percentage i.e. a value between 0 and 100
void AIC_setHPVolume(int volume)
{
	Uint16 hpvol;
	if((volume >=0) && (volume <= 100))
	{
		//convert %volume range to AIC_HP_VOL range
		//i.e. 0-100 range to (AIC_MIN_HP_VOL - AIC_MAX_HP_VOL) range
		hpvol = volume*(AIC_MAX_HP_VOL - AIC_MIN_HP_VOL)/100 + AIC_MIN_HP_VOL;
		hpvol = HPVOLUME_ADDR | hpvol;

		AIC_write(hpvol);
	}
}
