/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: player.h,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#define PLAYER_VOLUME_MAX	100	//100% of AIC rating
#define PLAYER_VOLUME_MIN	10	//10% of AIC rating
#define PLAYER_VOLUME_DELTA	 2	//delta change in volume for 1 keypress of volume change

#define PLAYER_VOLUME_DEFAULT 60	//default player volume 60%

#define MAX_FILES_IN_DIRECTORY 50



enum PLAYER_STATE {

STOPPED = 0,
PLAYING,
PAUSED,
FORWARDING,
REWINDING
};


typedef struct PLAYER
{
	char directory[80];		//directory of the current file to be/being played
	int fileIdx;			//index of the file in the file list to be/being played
	int volume;		//audio volume level
	
	int totalFiles;		//total number of files in current directory
	int fileIdxList[MAX_FILES_IN_DIRECTORY];	//list of file indexes in the current directory
							//a file index is nothing but the offset at which it occurs in the FAT
							//e.g. a file entry which comes 3rd in the FAT of current directory will have a file index of 2 (zero biased offset)
							//in the order in which they will be played.
							//This is a list of all files (including non audio files)
	int state;	//player state, i.e. playing, stopped, etc

	FILE *fp;	//file pointer to file that is being played
}PLAYER;

int PlayerInit(PLAYER *pPlayer);
int PlayerStartPlay(PLAYER *pPlayer);
int GetNextAudioFile(PLAYER *pPlayer);
int GetPreviousAudioFile(PLAYER *pPlayer);
void PlayerTask();
