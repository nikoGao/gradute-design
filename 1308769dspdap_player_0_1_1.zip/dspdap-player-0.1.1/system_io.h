/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: system_io.h,v 1.5 2007/06/06 12:09:22 Roger Exp $
 */

//----------board I/Os-----------
#define IO_PGOOD	GPIO_PIN7	//I	//set as Output only when shutting down player
#define IO_LED		GPIO_PIN4	//O

#define IO_KEY0		AGPIO_PIN3	//I
#define IO_KEY1		AGPIO_PIN4	//I
#define IO_KEY2		AGPIO_PIN5	//I
#define IO_CFPRESENT	AGPIO_PIN6	//I
//#define IO_SHUTOFF	AGPIO_PIN7	//not used
//actually IO_SHUTOFF is not require. making IO_PGOOD as output
//and making it low will shut off the system

/*
//key codes according to modified board (pre 0.1)
enum KEY_CODE { KEY_VOL_UP = 3,
				KEY_VOL_DOWN = 6,
				KEY_NEXT = 5,
				KEY_BATT_LOW = 8
			};
*/


//key codes according to schematic (0.1 onwards)
enum KEY_CODE {KEY_VOL_UP = 1,
		KEY_VOL_DOWN,
		KEY_PAUSE,
		KEY_PREV,
		KEY_NEXT,
		KEY_STOP,
		// codes 0 and 7 are reserved for invalid key and no keypress
		KEY_BATT_LOW = 8
		};


//---------USB idle control macros-------------
#define _USBIDLECTL_ADDR 0x7000
#define _USBDPLL_ADDR	0x1E00

#define USBIDLECTL 	PREG16(_USBIDLECTL_ADDR)
#define USBDPLL	PREG16(_USBDPLL_ADDR)

#define SET_USBIDLE()	(USBIDLECTL |= 0x5)	//USB reset and usb idle
#define CLR_USBIDLE() 	(USBIDLECTL &= ~0x5)


#define USB_PLLENABLE()	(USBDPLL |= 0x0010)
#define USB_PLLDISABLE() (USBDPLL &= ~(0x0010))


//--------I2C idle control--------------------
//NOTE: this is valid for TMS320VC5503/5507/5509A only

#define _I2CMDR2_ADDR	0x3C0F	//mode control 2 register.. not present in existing CSL
#define I2CMDR2	PREG16(_I2CMDR2_ADDR)

#define SET_I2CIDLE() (I2CMDR2 |= 1);
#define CLR_I2CIDLE() (I2CMDR2 &= ~1);
