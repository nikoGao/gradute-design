/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: usb_task.c,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#include "usb_task.h"
#include "IO.h"
#include "CF.h"
#include "mass_storage.h"
#include "usb_debug.h"
#include "FAT32.h"
#include "file.h"

//globals
GIO_Handle readChan, writeChan; 
int	usbConnected = 0;
extern SEM_Obj usbDeviceConnect; /* sem posted when host enumerates bus */

//static
FIXED_SENSE_DATA sense_data;		//stores sense data of current command
FIXED_SENSE_DATA prev_sense_data;	//stores sense data of previous command
STANDARD_INQUIRY_DATA std_inquiry_data;
READ_CAPACITY_10_DATA read_capacity10_data;
MODE_PARAMETER_HEADER	mode_parameter_header;


//packs a c55x string in which each character occupies 2 bytes into 
//a string in which each 2 characters use 2 bytes.
void strpack(const char * srcptr, char * destptr, unsigned int dest_size)
{
	//NOTE: destination size is size of destination bufer in MAUS.
	int i;
	for(i=0; i < dest_size; i++)
	{
		
		*destptr = *srcptr;
		
		if(*srcptr == 0)
			break;
		
		srcptr++;

		*destptr |= (*srcptr << 8) & 0xFF00;	//next char in MSWord
		
		if(*srcptr == 0)
			break;

		srcptr++;		
		destptr++;
	}
}


//forms the 32-bit word from the command block (CBWCB)
//requires the pointer to MSB of 32-bit word in CBWCB
unsigned long get_long_from_CBWCB(char *pCBWCB)
{
	unsigned long tlong;
	tlong = (pCBWCB[0] << 8) | (pCBWCB[1] & 0xFF);
	tlong = (tlong << 16) | 0xFFFF & ((pCBWCB[2] << 8) | (pCBWCB[3] & 0xFF));
	return tlong;
}

//forms the 16-bit word from the command block (CBWCB)
//requires the pointer to MSB of 16-bit word in CBWCB
unsigned int get_int_from_CBWCB(char *pCBWCB)
{
	unsigned int tint;
	tint = (pCBWCB[0] << 8) | (pCBWCB[1] & 0xFF);
	return tint;
}


extern char filePath[];
extern char dirPath[50];
extern char fileName[32];
char filebuf[256];	//to be removed.

void MsdTask()
{
	FILE* fp;
	UI32 dirCluster;
    Int status;                                
    unsigned int word,tword;
    int i, j;
	int *bufPtr;
	int bufSize;    
    Uns requestSize;
    C5509_USB_AppCallback deviceConnectCb = {
        (C5509_USB_TappCallback)SEM_post,
        &usbDeviceConnect   // semaphore to post when connected
    };
    C5509_USB_StateInfo info;
    CSW csw;
    CBW cbw;
    int wait_for_reset = 0;
//    unsigned long lastLBA = 0x7FFF;
    unsigned long lastLBA = 0;
    unsigned long BlockLength = 512;
    unsigned long LBA = 0;
    unsigned long num_sectors = 0;

	LED_on();
	    
    // create bulk type dsp input channel for USB OUT(from host) endpoint #2 
    readChan = GIO_create( "/udevUsb2", IOM_INPUT, NULL, NULL, NULL);

    if (readChan == NULL) {
        SYS_abort("Create input channel FAILED.");
    }
     
    // create bulk type dsp output channel for USB IN(to host) endpoint #2 
    
    writeChan = GIO_create( "/udevUsb2", IOM_OUTPUT, NULL, NULL, NULL);
    
    if (writeChan == NULL ) {
        SYS_abort("Create output channel FAILED.");
    }

    //  Connect the device to the host.
    //  The deviceConnectCb Fxn(SEM_post) will get called with arg(sem handle)
    //  when connection is made(host enumerated bus) or immediately called if
    //  bus is already connected.
    GIO_control(readChan, C5509_USB_DEVICECONNECT, &deviceConnectCb);
    SEM_pend(&usbDeviceConnect, SYS_FOREVER);	// block until bus is connected

	
	usbConnected = 1;

    GIO_control(readChan, C5509_USB_GETSTATEINFO, &info);

	//Get Compact Flash information
	if(CF_IdentifyDrive() == -1)
	{
		//error executing identify drive command;
		lastLBA = 0;
	}
	else
	{
		//get number of Blocks on CF card
		lastLBA = cf_buffer.data[7];
		lastLBA = (lastLBA << 16) | cf_buffer.data[8];
		
		//last LBA is (number of blocks - 1) as LBA starts from 0
		lastLBA--;
//		lastLBA = 0x1FFF;	//4MB
//		lastLBA = 0x7FFF;	//16MB
//		lastLBA = 0xFFFF;	//32MB
	}
	
	//form standard inquiry data
	memset(&std_inquiry_data, 0, sizeof(std_inquiry_data));		//clear inquiry data
	std_inquiry_data.PERIPHERAL_QUALIFIER = 0;	//000b
	std_inquiry_data.PERIPHERAL_DEVICE_TYPE = 0;	//Direct Access block device SBC-2
	std_inquiry_data.RMB = 1;    //Removable
	std_inquiry_data.VERSION = 0x4;	//device complies to SPC-2
	std_inquiry_data.RESPONSE_DATA_FORMAT = 2;     //SPC-2 data format
	std_inquiry_data.ADDITIONAL_LENGTH = 31;	//31 bytes to transfer after additional length parameter
	
	strpack("DSPdap", std_inquiry_data.T10_VENDOR_ID_STRING, sizeof(std_inquiry_data.T10_VENDOR_ID_STRING));
	strpack("CF Flash Disk", std_inquiry_data.PRODUCT_ID_STRING, sizeof(std_inquiry_data.PRODUCT_ID_STRING));
	strpack("0.10", std_inquiry_data.PRODUCT_REV_STRING, sizeof(std_inquiry_data.PRODUCT_REV_STRING)); 

	//form mode parameter header data that needs to be returned during MODE SENSE command
	memset(&mode_parameter_header, 0, sizeof(mode_parameter_header));
	mode_parameter_header.MEDIUM_TYPE = 0x0;	//for SBC-2
	mode_parameter_header.WP = 0;	//write protect enabled..temporarily.
	mode_parameter_header.DPOFUA = 0;	//DPO and FUA not supported
	mode_parameter_header.MODE_DATA_LENGTH = 3;
	        
    //clear sense data.
	memset(&sense_data, 0, sizeof(sense_data));
	sense_data.RESPONSE_CODE = 0x70;	//current errors
	sense_data.SENSE_KEY = NO_SENSE;
	sense_data.ADDITIONAL_SENSE_CODE = NO_ADDITIONAL_SENSE_INFORMATION;
	sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = NO_ADDITIONAL_SENSE_INFORMATION_Q;


	while(1)
	{
		//check if host has issued a BULK_ONLY_MASS_STORAGE_RESET command
		
		if(SEM_pend(&usbMassStorageResetReceived, 0) == TRUE)
		{
			//got a reset command
			i = SEM_count(&usbMassStorageResetReceived);
			//clear out any multiple postings.
			//need to fix a bug. dunno why setup handler is executed twice.
			//each time a reset command is received, the semaphore count
			//is incremented by 2.
			//above sem_pend will decrement count to 1 but we need count to
			//return to 0. 
//			SEM_reset(&usbMassStorageResetReceived, 0); //make semaphore count to zero
			                                           	
//			usb_print_str("Resetting device...");
			wait_for_reset = 0;
						
			//indicate to our control endpoint handler 
			//that reset operation has been completed
			SEM_post(&usbMassStorageResetComplete);			
//			SEM_post(&usbMassStorageResetComplete);						
		}

		if(wait_for_reset)
		{
			continue;	//do not execute rest of code if we need to wait for reset command
		}

		if(ms_get_CBW(&cbw))
		{
			//invalid CBW received
//			usb_print_str("invalid CBW");			
			//stall both endpoints and wait for reset command
			GIO_control(readChan, C5509_USB_STALL_EP, 0);
			GIO_control(writeChan, C5509_USB_STALL_EP, 0);
			wait_for_reset = 1;
		}
		else
		{
			memset(&csw, 0, sizeof(csw));	//clear csw
			//got a valid CBW
			csw.dCSWSignature = CSW_SIGNATURE;
			csw.dCSWTag = cbw.dCBWTag;
			csw.dCSWDataResidue = 0;
			csw.bCSWStatus = 0;
			csw.bCSWStatus = COMMAND_PASSED;	//will be set to failed if command fails
			
			//save sense data of previous command.
			prev_sense_data = sense_data;        
        	//clear sense data
			memset(&sense_data, 0, sizeof(sense_data));			
			sense_data.RESPONSE_CODE = 0x70;	//current errors
			sense_data.SENSE_KEY = NO_SENSE;
			sense_data.ADDITIONAL_SENSE_CODE = NO_ADDITIONAL_SENSE_INFORMATION;
			sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = NO_ADDITIONAL_SENSE_INFORMATION_Q;

			//Data transfer is from device to host (Bulk-In transfer)
			//Check all supported commands that need a Bulk-In data transfer
			switch(cbw.CBWCB[0])	//check which command
			{
				case 0x12:	//INQUIRY
					if(cbw.bmCBWFlags & 0x80 == 0)
					{
						//command's and flag's data directions mismatch
						//host want to send data (flag == 0) but device also
						//want to send data (inquire command)
						//This is case 10 (of the 13 possible cases)
						csw.bCSWStatus = PHASE_ERROR;
						//stall the bulk-out endpoint as host wants to send data
						GIO_control(readChan, C5509_USB_STALL_EP, 0);
						
						break;	//exit switch statement
					}
					if(cbw.CBWCB[1] & 0x1)
					{
						//EVPD == 1 so need to send Vital Product data
						//specified by PAGE_CODE
							//currently unsupported so we consider as invalid field
							//and terminate command with CHECK_CONDITION status
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed						
					}
					else
					{
						//EVPD == 0 so need to send standard INQUIRY data
						//PAGE_CODE must be zero
						if(cbw.CBWCB[2] != 0)
						{
							//error. invalid filed in CDB..update sense data
							//and terminate command with CHECK_CONDITION status
							sense_data.SENSE_KEY = ILLEGAL_REQUEST;
							sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
							sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
							csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed
						}
						else
						{
							//send Standard Inquiry data                         
							requestSize = STANDARD_INQUIRY_DATA_LENGTH;           
							csw.bCSWStatus = COMMAND_PASSED;							
							csw.dCSWDataResidue = cbw.dCBWDataTransferLength - requestSize;							
							GIO_write(writeChan, &std_inquiry_data, &requestSize);
						}
					}
					break;
				
				case 0x3:	//REQUEST SENSE
					if(cbw.bmCBWFlags & 0x80 == 0)
					{
						//command's and flag's data directions mismatch
						//host want to send data (flag == 0) but device also
						//want to send data (inquire command)
						//This is case 10 (of the 13 possible cases)
						csw.bCSWStatus = PHASE_ERROR;
						//stall the bulk-out endpoint as host wants to send data
						GIO_control(readChan, C5509_USB_STALL_EP, 0);
						
						break;	//exit switch statement
					}
					if(cbw.CBWCB[1] & 0x1)
					{
						//DESC == 1 so need to send Descriptor format sense data
							//currently unsupported so we consider as invalid field
							//and terminate command with CHECK_CONDITION status
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed						
					}
					else
					{
						//DESC == 0 so need to send fixed format sense data     
						requestSize = FIXED_SENSE_DATA_LENGTH;
						csw.bCSWStatus = COMMAND_PASSED;
						csw.dCSWDataResidue = cbw.dCBWDataTransferLength - requestSize;
						GIO_write(writeChan, &prev_sense_data, &requestSize);
					}
					break;
					
				case  0x25:	//READ CAPACITY 10
					if( cbw.CBWCB[2] || cbw.CBWCB[3] || cbw.CBWCB[4] || cbw.CBWCB[5] || (cbw.CBWCB[8] & 0x1))
					{
						//LBA is not zero or PMI != 0
						//such a command is currently not supported
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed												
					}
					else
					{
						//LBA == 0 and PMI == 0
						read_capacity10_data.LBA_3 = lastLBA >> 24;
						read_capacity10_data.LBA_2 = lastLBA >> 16;
						read_capacity10_data.LBA_1 = lastLBA >> 8;
						read_capacity10_data.LBA_0 = lastLBA;
						read_capacity10_data.BLOCK_LENGTH_3 = BlockLength >> 24;
						read_capacity10_data.BLOCK_LENGTH_2 = BlockLength >> 16;
						read_capacity10_data.BLOCK_LENGTH_1 = BlockLength >> 8;
						read_capacity10_data.BLOCK_LENGTH_0 = BlockLength;
						
						requestSize = READ_CAPACITY_10_DATA_LENGTH;
						GIO_write(writeChan, &read_capacity10_data, &requestSize);
						csw.bCSWStatus = COMMAND_PASSED;
					}
					break;
					
				case 0x28:	//READ 10
					if(cbw.CBWCB[1] | cbw.CBWCB[6])
					{
						//unsupported fields set in CDB
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed												
						break;
					}

					//get start LBA address to read from
					LBA = get_long_from_CBWCB(&cbw.CBWCB[2]);       
					//get number of sectors to read
					num_sectors = get_int_from_CBWCB(&cbw.CBWCB[7]);
					
					if( (LBA + num_sectors - 1) > lastLBA)
					{
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE_Q;
						csw.bCSWStatus = COMMAND_FAILED;
						break;
					}         
					
					if(num_sectors > 255)
					{
						//num_sectors > 255 not supported
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;
						break;
					}

					csw.bCSWStatus = COMMAND_PASSED;

					if(CF_ReadSectors(LBA, num_sectors))
					{
						//error..CF busy or not ready.
						sense_data.SENSE_KEY = NOT_READY;
						sense_data.ADDITIONAL_SENSE_CODE = status;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = 0;
						csw.bCSWStatus = COMMAND_FAILED;			
						CF_HardReset();
						break;
					}
					else
					{
						while(num_sectors > 0)
						{
							//read 1 sector data to cf_buffer
							status = read_sector(DATA_REG, cf_buffer.data);
                         
	                        if(status != 0)
    						{
    							//error..DRQ was not set
								sense_data.SENSE_KEY = NOT_READY;
								sense_data.ADDITIONAL_SENSE_CODE = status;
								sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = 0;
								csw.bCSWStatus = COMMAND_FAILED;			
								CF_HardReset();
								break;
							}			
						
							//else read was successful.. transfer 512 bytes to host
							requestSize = 512;
							GIO_write(writeChan, &cf_buffer, &requestSize);
							num_sectors --;
						}
					}
					break;
				
				case 0x0:	//TEST UNIT READY
					//we assume unit is ready so pass the command
					csw.bCSWStatus = COMMAND_PASSED;
					break;
					
				case 0x1A:	//MODE SENSE
					requestSize = MODE_PARAMETER_HEADER_LENGTH;
					GIO_write(writeChan, &mode_parameter_header, &requestSize);
					csw.bCSWStatus = COMMAND_PASSED;
					break;
					
				case 0x2F:	//VERIFY 10 
				//NOTE: this command is used by windows during a full format.
					if(cbw.CBWCB[1] != 0)
					{   
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed						
						break;
					}   

					//as BYTCHK is zero we are not expecting any data from host for comparison for verification
					if(cbw.dCBWDataTransferLength != 0)
					{
						//host is expecting to send data but we don't need any data
						csw.bCSWStatus = COMMAND_FAILED;    //will stall the appropriate endpoint
						break;
					}

					//we will not perform any verification and just blindly say that things were verified
/*					
					//%%%%%%%%%%%%%%%%%%%%%%%%%%%
					//get start LBA address to verify from
					LBA = get_long_from_CBWCB(&cbw.CBWCB[2]);       
					//get number of sectors to verify
					num_sectors = get_int_from_CBWCB(&cbw.CBWCB[7]);

					if( (LBA + num_sectors - 1) > lastLBA)
					{   
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE_Q;
						csw.bCSWStatus = COMMAND_FAILED;
						break;
					}         
                    
					//LBA is in range
					while(num_sectors > 0)
					{
						status = CF_WriteSector(LBA);     
                     	if(status != 0)
    					{
							sense_data.SENSE_KEY = NOT_READY;
							sense_data.ADDITIONAL_SENSE_CODE = status;
							sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = 0;
							csw.bCSWStatus = COMMAND_FAILED;			
							break;
						}			
						//else read was successful.. transfer 512 bytes to host
    					num_sectors--;
						LBA++;
					}
					//%%%%%%%%%%%%%%%%%%%%%%%%%%%					
*/					
					csw.bCSWStatus = COMMAND_PASSED;                    					
					break;
					
				case 0x1E:	//PREVENT ALLOW MEDIUM REMOVAL
					csw.bCSWStatus = COMMAND_PASSED;
					break;
					
				case 0x2A:	//WRITE 10              
					if(cbw.CBWCB[1] | cbw.CBWCB[6])
					{
						//unsupported fields set in CDB
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;	//indicate command failed												
						break;
					}
					//get start LBA address to write to
					LBA = get_long_from_CBWCB(&cbw.CBWCB[2]);       
					//get number of sectors to write
					num_sectors = get_int_from_CBWCB(&cbw.CBWCB[7]);
					if( (LBA + num_sectors - 1) > lastLBA)
					{   
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE_Q;
						csw.bCSWStatus = COMMAND_FAILED;
						break;
					}         
					//LBA is in range
					
					if(num_sectors > 255)
					{
						//num_sectors > 255 not supported
						sense_data.SENSE_KEY = ILLEGAL_REQUEST;
						sense_data.ADDITIONAL_SENSE_CODE = INVALID_FIELD_IN_CDB;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_FIELD_IN_CDB_Q;
						csw.bCSWStatus = COMMAND_FAILED;
						break;
					}
                    
					csw.bCSWStatus = COMMAND_PASSED;                    

					if(CF_WriteSectors(LBA, num_sectors))
					{
						//error..CF busy or not ready.
						sense_data.SENSE_KEY = NOT_READY;
						sense_data.ADDITIONAL_SENSE_CODE = status;
						sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = 0;
						csw.bCSWStatus = COMMAND_FAILED;			
						CF_HardReset();					
						break;
					}
					else
					{
						while(num_sectors > 0)
						{
							requestSize = 512;
							//read from USB into CF buffer
							GIO_read(readChan, &cf_buffer, &requestSize);
							status = write_sector(DATA_REG, cf_buffer.data);
	                     	if(status != 0)
    						{
    							//error..DRQ not set
								sense_data.SENSE_KEY = NOT_READY;
								sense_data.ADDITIONAL_SENSE_CODE = status;
								sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = 0;
								csw.bCSWStatus = COMMAND_FAILED;			
								CF_HardReset();
								break;
							}			
							//else write was successful.
	    					num_sectors--;
	    				}
					}
					break;					
					
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
			//check for commands that don't need any data transfer
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&				
				default:
					//unrecognized/unsupported command
					
					csw.bCSWStatus = COMMAND_FAILED;
					sense_data.SENSE_KEY = ILLEGAL_REQUEST;
					sense_data.ADDITIONAL_SENSE_CODE = INVALID_COMMAND_OPERATION_CODE;
					sense_data.ADDITIONAL_SENSE_CODE_QUALIFIER = INVALID_COMMAND_OPERATION_CODE_Q;
					break;
			}             
			
			//check if command failed and stall appropriate endpoint
			if(csw.bCSWStatus == COMMAND_FAILED)
			{
				//check if data transfer expected is bulk-in or bulk-out type
				//and appropriately stall that endpoint.
				
				//we do not need to stall any endpoint if no data was expected
				if(cbw.dCBWDataTransferLength != 0)
				{
					if(cbw.bmCBWFlags & 0x80)
					{
						//stall the bulk-in endpoint
						GIO_control(writeChan, C5509_USB_STALL_EP, 0);
					}
					else
					{
						//stall the bulk-out endpoint
						GIO_control(readChan, C5509_USB_STALL_EP, 0);
					}
				}
			}
			ms_send_CSW(&csw);			
		}	//end else
	}	//end while
}
