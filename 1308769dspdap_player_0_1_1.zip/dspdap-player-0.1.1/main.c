/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: main.c,v 1.5 2007/06/06 12:09:22 Roger Exp $
 */

#include <std.h>

#include <gio.h>
#include <iom.h>
#include <sem.h>
#include <c5509_usb.h>

#include "playercfg.h"   

#include <csl.h>
#include <csl_mcbsp.h>
#include <csl_dma.h>
#include <csl_pll.h>
#include <csl_usb.h>
#include <csl_gpio.h>
#include <csl_i2c.h>

#include "mad.h"
#include "aic.h"
#include "IO.h"
#include "usb_debug.h"
#include "usb_task.h"
#include "FAT32.h"
#include "file.h"
#include "player.h"
#include "system_io.h"

#define DATASIZE    64             /* data size in bytes for usb read/write*/
#define USBBUFSIZE (DATASIZE/2 + 1)  /* first word reserved for transfer size */

#define BFSZ 1450


struct buffer {
  unsigned char start[BFSZ]; //char is 16-bit on C54x/C55x
  unsigned long size;
};


/****************DMA buffer***************************/
#define BUFSAMPLES 144	//number of stereo samples in 1 frame of DMA buffer
							//must be evenly divisible by 576

PCM_SAMPLE dma_buf1[BUFSAMPLES*2];	//stereo samples
PCM_SAMPLE dma_buf2[BUFSAMPLES*2];	//stereo samples

/******************************************************/
struct buffer buffer;

extern unsigned int hpi_bufaddr;
extern unsigned int hpi_frame1stat;
extern unsigned int hpi_frame2stat;
extern unsigned int hpi_framesize;

//configures the input/output direction of GPIOs
void config_GPIO()
{
	//configure GPIO pin directions
	GPIO_pinDirection(IO_PGOOD, GPIO_INPUT);
	GPIO_pinDirection(IO_LED, GPIO_OUTPUT);
	GPIO_pinDirection(GPIO_PIN6, GPIO_OUTPUT);	//GPIO6 is unused

	//configure AGPIO pin directions
	GPIO_pinDirection(IO_KEY0, GPIO_INPUT);
	GPIO_pinDirection(IO_KEY1, GPIO_INPUT);
	GPIO_pinDirection(IO_KEY2, GPIO_INPUT);

	GPIO_pinEnable(IO_KEY0);
	GPIO_pinEnable(IO_KEY1);
	GPIO_pinEnable(IO_KEY2);

}

//determines if usb is plugged into USB host or no
//return val: 	1 = yes, device plugged into USB host
//				0 = no, device is stand alone.
int IsUsbPlugged()
{
	int status;
	//we will determine if device is plugged into USB host or no
	//by observing the PGOOD line. if PGOOD is high, it means that
	//device is powering from battery (i.e. not USB), else device
	//is powering from USB.
	status = GPIO_pinRead(IO_PGOOD);

//	return 0;

	if(status)
		return 0;	//stand alone
	else
		return 1;	//USB plugged
}

#define	CLOCK_MULT 14	//should be an even number and <= 14
						//even number so that CLKOUT is = 12MHz for AIC chip

void main(int argc, char *argv[])
{
 	int i;
	PCM_SAMPLE *ptr;
	PLL_Config	pllConfig = {
					0,	/*iai*/
					0,	/*iob*/
					CLOCK_MULT, /*PLLMULT*/
					0,	/*DIV*/
				};

//------------initialize mad decoder----------------

  extern struct mad_stream *stream;

  // initialize our private message structure
  buffer.size = BFSZ;
  
  //initialize global variables used by decoder.
  mad_stream_init();
  mad_frame_init();
  mad_synth_init();
  
  //set BUFLEN error so that input_func() is 
  //executed the first time decoder is run.
  stream->error = MAD_ERROR_BUFLEN;

//-------------------------------------------------


//-------configure McBSP0 and DMA4 according to PCM_SAMPLE precision and DMA buffer size--------

	//configure DMACEN based on DMA bufer size		
	DMA_RSETH(hDma4, DMACEN, (BUFSAMPLES*2));	//*2 as they are stereo samples
	
	if(PCM_PRECISION > 16)
	{
		//reconfigure for 32-bit PCM sample
		DMA_FSETH(hDma4, DMACSDP, DATATYPE, DMA_DMACSDP_DATATYPE_32BIT);
		//for 32-bit DMA transfers destination start address must be that of DXR2
		//we need byte address..so left shift word address by 1
		DMA_RSETH(hDma4, DMACDSAL, (_MCBSP_DXR20_ADDR<<1)&0xFFFF);
		DMA_RSETH(hDma4, DMACDSAU, _MCBSP_DXR20_ADDR>>15);

		//configure McBsp0 for 32-bit.
		MCBSP_FSETH(hMcbsp0, XCR1, XWDLEN1, MCBSP_XCR1_XWDLEN1_32BIT);
	} 
	else
	{
		//reconfigure for 16-bit PCM sample
		DMA_FSETH(hDma4, DMACSDP, DATATYPE, DMA_DMACSDP_DATATYPE_16BIT);
		//for 16-bit DMA transfers destination start address must be that of DXR1
		//we need byte address..so left shift word address by 1
		DMA_RSETH(hDma4, DMACDSAL, (_MCBSP_DXR10_ADDR<<1)&0xFFFF);
		DMA_RSETH(hDma4, DMACDSAU, _MCBSP_DXR10_ADDR>>15);
		
		//configure McBsp0 for 16-bit.
		MCBSP_FSETH(hMcbsp0, XCR1, XWDLEN1, MCBSP_XCR1_XWDLEN1_16BIT);
	}

//----------configure CompactFlash interface------
	config_EMIF();
	CF_HardReset();

//----------configure GPIOs-----------------------
	config_GPIO();
	
//-----------configure PLLs------------------------
	//configure USB PLL first. so that ratio of CLK:USBCLK is never > 12:1 ... see 5507_errata
	USB_initPLL(12, 48, 0);	

	//Configure PLL
	PLL_config(&pllConfig);
	//set CLKOUT pin to 12MHz for AIC
	
	//write a value that is half of PLLMULT into SYSREG:CLKDIV so that
	//the frequency on CLKOUT pin remains equal to CLKIN i.e. 12MHz.
	//e.g. if PLLMULT is 14 then write 7.
	//only a value between 0 and 7 can be written to SYSREG:CLKDIV
//	asm("	MOV #6h, port(#07FDh)");		
	PREG16(0x07FD) = (CLOCK_MULT>>1);

//---------------------------------------------------


	asm("	OR #4000h, mmap(@IER0)");	//enable DMA4 interrupt	  
	
 	AIC_init();		//initialize AIC chip

  	//mute DMA buffers

  	ptr = dma_buf1;
  	for(i=0; i<BUFSAMPLES*2; i++)	//x2 cause to clear both buffers
  	{
  		*ptr++ = 0;	//left sample
  		*ptr++ = 0;	//right sample
  	}
/*		
	DMA_start(hDma4);	//start DMA transfer
	MCBSP_FSETH(hMcbsp0, SPCR2, XRST, 1); //turn on transmitter	
*/	
  	//fall into the DSP/BIOS kernel
  	LED_off();
}


int led_flag = 1;
void Toggle_LED()
{
	if(led_flag)
		LED_on();
	else
		LED_off();

	led_flag ^= 1;	//toggle LED flag
}

//DMA4 ISR
void dma4isr()
{
	//read DMACSR (status register) to clear the interrupt flags
	//this step is very important otherwise the DMA interrupt will not fire next time
	DMA_RGETH(hDma4,DMACSR);
	
	SWI_post(&SWI_pcm);
}



/*
 * This is the input callback. The purpose of this callback is to (re)fill
 * the stream buffer which is to be decoded. In this example, an entire file
 * has been mapped into memory, so we just call mad_stream_buffer() with the
 * address and length of the mapping. When this callback is called a second
 * time, we are finished decoding.
 */
extern struct mad_stream *stream;

int new_bytes=0;
int stream_bytes_left;
unsigned char *buf_ptr;
int frame_phase=0;
int frame_left=0;
unsigned int *frame_ptr;

extern PIP_Obj input_pipe;

int input_func()
{
//	usb_print_str("input func");
	if(new_bytes == 0)
	{
	  //previous input request was completed.
	  stream_bytes_left = stream->bufend - stream->this_frame;
	  buf_ptr = buffer.start + stream_bytes_left;
	  new_bytes = BFSZ - stream_bytes_left;
	  
	  //move unprocessed bytes in buffer to the top
	  memcpy(buffer.start, stream->this_frame, stream_bytes_left);
	}
	//new_bytes indicates number of new bytes to fill into
	//the stream buffer	
	while(new_bytes > 0)
	{
		if(frame_left == 0)
		{
			//zero bytes pending in frame
			if(PIP_getReaderNumFrames(&input_pipe) == 0)
			{
				//no full frame available to read, so exit.
				return -1;
			}
			//else we have at least 1 full frame
			PIP_get(&input_pipe);
			frame_ptr = (unsigned int*)PIP_getReaderAddr(&input_pipe);
			frame_left = PIP_getReaderSize(&input_pipe);
			frame_phase = 0;
		}
		
		//now we have something left in the frame
		
		//NOTE: the host channel packs 2 bytes of a file
		//into 1 word so we have to unpack it.
		//we use frame_phase to indicate which byte of
		//the word is to be read.(i.e. MSB or LSB)
		
		//first byte is in LSB position and second byte
		//is in MSB position.
		if(frame_phase == 0)
		{   
			//extract LSB
			*buf_ptr++ = (*frame_ptr)&(0x00ff);		
			frame_phase = 1;
		}
		else
		{   
			//extract MSB
			*buf_ptr++ = ((*frame_ptr)&(0xff00)) >> 8;						
			frame_phase = 0;
			//1 word read
			frame_ptr++;
			frame_left--;
		}
		//1 byte filled in stream buffer
		new_bytes--;
		
		if(frame_left==0)
		{
			//frame emptied so free it
			PIP_free(&input_pipe);	//posts SWI_data
		}
		
	}  //end while(new_bytes > 1)
	
	mad_stream_buffer(buffer.start, buffer.size);
	
	return 0;
}


#ifndef WAVE_DEBUG
int buf_flag=0;	//indicates which frame of dma_buf should be filled

int gotflag=0;
PCM_SAMPLE *pcm_ptr=0;
int pcm_left=0,size=0;
#endif

//fills DMA buffer appropriately
void pcm_func()
{
#ifndef WAVE_DEBUG

	PCM_SAMPLE *dma_buf_ptr;
	int i;
	
	if(buf_flag==0)
	{
		//DMA finished with frame 1 so fill frame 1
		dma_buf_ptr = dma_buf1;
		buf_flag = 1;
//		LED_off();
	}
	else
	{
		//DMA finished with frame 2 so fill frame 2
		dma_buf_ptr = dma_buf2;
		buf_flag = 0;
//		LED_on();		
	}
	
	if(pcm_left == 0)
	{
		//pcm buffer empty see if new samples are available
		//and reload pcm_buffer
		if(PIP_getReaderNumFrames(&output_pipe) == 0)
		{
			//no full frame to read
			SWI_post(&SWI_decode); //ensure decoder is running
		}
		else
		{	//there is a full frame in output_pipe
			PIP_get(&output_pipe);
			gotflag = 1;
			pcm_ptr = (PCM_SAMPLE *)PIP_getReaderAddr(&output_pipe);
		    //now pcm_ptr points to a buffer containing 576 stereo (32-bit) samples.			
		    
			size = PIP_getReaderSize(&output_pipe);//now size contains number of words
			
			size /= sizeof(PCM_SAMPLE);	//now size contains number PCM_SAMPLES.
			
			pcm_left = size/2;	  //number of PCM stereo samples	

		}
	}			
	
	if(pcm_left == 0)
	{	
//		LED_on();	
		//i.e. no new pcm samples so fill zeros in dma buffer
		for(i=0; i<BUFSAMPLES; i++)
		{
			*dma_buf_ptr++ = 0;	//left sample
			*dma_buf_ptr++ = 0; //right sample
		}
	}
	else
	{
//		LED_off();

		for(i=0; i<BUFSAMPLES; i++ )
		{
			*dma_buf_ptr++ = (*pcm_ptr); 	//left sample

			*dma_buf_ptr++ = (*(pcm_ptr+576));	 //right sample
			pcm_ptr++;
		}
		
		pcm_left -= BUFSAMPLES;		
	}

	if( (pcm_left == 0) && (gotflag == 1))
	{
		//frame got empty.
		PIP_free(&output_pipe);  
		gotflag = 0;
	}
#endif
}
	

//checks if device plugged into USB or no and runs appropriate function
void SystemTask()
{

	//enable EX-INT0 only if not plugged into USB.
	if(!IsUsbPlugged())
	{
		asm("	OR #0004h, mmap(@IER0)");	//enable EX-INT0 interrupt	  
	}

	if(IsUsbPlugged())
	{
	//------build the power down configuration----------
		//set Peripheral domain idle, in Idle config register
		//now all those peripherals who's IDLEEN is set will go in IDLE mode
		//when IDLE instructions is executed
		PWR_FSET(ICR, PERI, 1);

		//set cache idle as we're not using it
		PWR_FSET(ICR, CACHEI, 1);

		//set DMA idle. it will automatically come out of idle when
		//Mcbsp needs it, and go back to idle
		PWR_FSET(ICR, DMAI, 1);


		//set power down enable for AIC data port
		MCBSP_FSETH(hMcbsp0, PCR, IDLEEN, 1);

		//set power down enable for AIC control port
		MCBSP_FSETH(hMcbsp1, PCR, IDLEEN, 1);

		//set power down enable for Mcbsp 2 (used for I/O only)
		MCBSP_FSETH(hMcbsp2, PCR, IDLEEN, 1);


		//set power down enable for I2C module
		SET_I2CIDLE();


	//----------Go in power down mode-------------------
//		PWR_powerDown(PWR_WAKEUP_MI);	//executes the IDLE instruction.
		asm("	IDLE");
		MsdTask();
	}
	else
	{
		//prepare to execute player task
		//Player runs on battery so we will put the unused peripherals
		//in idle mode for power saving.

//------build the power down configuration----------

		//set Peripheral domain idle, in Idle config register
		//now all those peripherals who's IDLEEN is set will go in IDLE mode
		//when IDLE instructions is executed
		PWR_FSET(ICR, PERI, 1);

		//set cache idle as we're not using it
		PWR_FSET(ICR, CACHEI, 1);

		//set DMA idle. it will automatically come out of idle when
		//Mcbsp needs it, and go back to idle
		PWR_FSET(ICR, DMAI, 1);

		//set power down enable for AIC data port
		//will be automatically brought out of idle by DMA interrupt
		//and go back to idle.
		MCBSP_FSETH(hMcbsp0, PCR, IDLEEN, 1);

		//set power down enable for Mcbsp 2 (used for I/O only)
		MCBSP_FSETH(hMcbsp2, PCR, IDLEEN, 1);

#ifndef USB_DEBUG	
		//set power down enable for USB module
		SET_USBIDLE();

		//disable USB PLL (i.e. set it in bypass mode) for power saving
		USB_PLLDISABLE();
		//set bypass clock to divide by 4		
		USBDPLL |= 0x0030;	
#endif

		//set power down enable for I2C module
		SET_I2CIDLE();

//----------Go in power down mode-------------------
//		PWR_powerDown(PWR_WAKEUP_MI);	//executes the IDLE instruction.
		asm("	IDLE");

//----------execute player task---------------------
		PlayerTask();
	}
}

//gets called every 100ms by PRD_keyscan
//NOTE: PRD is a kind of SWI..so we should exit as soon as possible
Void keyscan()
{
		static int last_keypress = 0;
		static int keycount = 0;
		int key_id;
/*
		if(!GPIO_pinRead(IO_KEY_VOL_UP))
		{
			key_id = KEY_VOL_UP;
			MBX_post(&MBX_keys, &key_id, 0);	// timeout = 0. return immediately
		}
		if(!GPIO_pinRead(IO_KEY_VOL_DOWN))
		{
			key_id = KEY_VOL_DOWN;
			MBX_post(&MBX_keys, &key_id, 0);	// timeout = 0. return immediately
		}
		if(!GPIO_pinRead(IO_KEY_NEXT))
		{
			key_id = KEY_NEXT;
			MBX_post(&MBX_keys, &key_id, 0);	// timeout = 0. return immediately
		}
*/
		key_id = GPIO_pinRead(AGPIO_PIN5)<<2;
		key_id |= GPIO_pinRead(AGPIO_PIN4)<<1;
		key_id |= GPIO_pinRead(AGPIO_PIN3);

		if(key_id == 0 || key_id == 7)
		{
			//invalid key code or key released
			last_keypress = keycount = 0;
			return;
		}

		if(key_id != last_keypress)
		{
			//new key pressed
			keycount = 0;
			last_keypress = key_id;
		}
		else
		{
			//key is still pressed
			keycount++;

			//we will send a keypress event after 100ms debounce
			if(keycount==1)
			{
					MBX_post(&MBX_keys, &key_id, 0);
			}

			//send a keypress every 400ms if it is a volume key
			if( (keycount & 3) == 0)
			{
					if( (key_id==KEY_VOL_UP) || (key_id==KEY_VOL_DOWN) )
					{
								MBX_post(&MBX_keys, &key_id, 0);
					}
			}

		}
}


//we will flash LED thrice and then shut down system
void battery_low_ISR()
{
	int key_id;
	key_id = KEY_BATT_LOW;
	MBX_post(&MBX_keys, &key_id, 0);
}
