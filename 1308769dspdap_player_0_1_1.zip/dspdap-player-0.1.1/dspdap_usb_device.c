/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: dspdap_usb_device.c,v 1.2 2007/06/05 11:53:57 Roger Exp $
 */

#include <std.h>
#include <csl.h>
#include <c5509_usb.h>           
#include <sem.h>
#include <gio.h>
#include "playercfg.h"
#include "mass_storage.h"
#include "usb_debug.h"

extern GIO_Handle readChan, writeChan; 

/*
 * Control Endpoint 0 IN and OUT USB event mask.
 */
#define EP0EVENTMASK  (USB_EVENT_RESET | USB_EVENT_SETUP | USB_EVENT_SUSPEND | \
        USB_EVENT_RESUME | USB_EVENT_EOT)

/*
 *  Device Descriptor
 */
static Uint16 deviceDescriptor[] = {
  0x0000,    /* field for xfer_byte_cnt - used by the data */
             /* transfer API, not an integral part of descriptor */
  (C5509_USB_DESCRIPTOR_DEVICE<<8) | 18,    /* bLength, bDescriptorType */
  0x0101,    /* bcdUSB */
  0x0000,    /* bDeviceClass = 0, bDeviceSubClass = 0  i.e. class & subclass are specified in interface descriptor*/
  0x4000,    /* bDeviceProtocol = 0 (specified in interface), bMaxPacketSize0 = 64 */
  0x0451,    /* idVendor = Texas Instruments */
#ifdef USB_DEBUG
  0x9003,    /* idProduct = catalog DSP product for 5507 */
#else
  0x9004,	/*Roger's USB disk*/
#endif
  0x0010,    /* bcdDevice ID = 00.10 = revision 0.1 */
  0x0201,    /* iManufacturer, iProductName */
  0x0100     /* iSerialNumber, bNumConfigurations */
};

/*
 *  String Descriptors Language Id
 */
static Uint16 stringDescriptorLangId[] = {
  0x0000, /* field for xfer_byte_cnt - used by the data */
          /* transfer API, not an integral part of descriptor */
  (C5509_USB_DESCRIPTOR_STRING<<8) | 4,  /* bLength, bDescriptorType */
  0x0409, /* LANGID (English) */
  0x0000  
};

/*
 *  String Descriptor
 */
static String stringDescriptor[] = {
  (char *)&stringDescriptorLangId[0],    /* LANGID */
  "  Roger Quadros http://dspdap.sourceforge.net",    /* iManufacturer */
  "  DSPdap - Digital Audio Player",    /* iProductName */
  "  USB Mass Storage Device",    /* iConfiguration */
  "  SCSI transparent command set",    /* iInterface - Vendor Specific */
  NULL                    /* end of string descriptor */
};


/*
 * Override default non-setup event handler
 */
static Void dapEvtCb( Uint16 event, C5509_USB_UsbEventHandler handler) {

    if (event == USB_EVENT_RESET) {
        /* 
         * application can extend functionality here.
         */
        handler();    /* call the default reset event handler */
    }
    else if (event == USB_EVENT_SUSPEND) {
        /* 
         * application can extend functionality here
         */
        handler();    /* call the default suspend event handler */
    }
}


/*
 * Override default setup event handler
 */
static C5509_USB_UsbReqRet dapSetupEvtCb( Uint16 requestId,
        C5509_USB_UsbReqHandler handler, USB_SetupStruct *setupPacket) {
        
    /* 
     * application can extend functionality here.
     */
	C5509_USB_UsbReqRet retVal;    
    
    //Check and process any supported setup requests
    
    //Check if request is a Class request and recipient is interface	
    //D6..5 = type and D4..0 = recipient
   	//check for class specific request
	if(setupPacket->bmRequestType == 0x21 && setupPacket->bRequest == BULK_ONLY_MASS_STORAGE_RESET)
	{
    	//BULK_ONLY_MASS_STORAGE_RESET command received
		//check if parameters valid    	
  		if(setupPacket->wValue == 0 && setupPacket->wLength == 0)
   		{
			//indicate to the application that a reset command has been received
			SEM_post(&usbMassStorageResetReceived);
	//#######################################################
	//PERFORM reset operations here
	//#######################################################

			//terminate all read write operations
			//this will unblock any pending GIO_read/writes.
			GIO_control(readChan, IOM_CHAN_RESET, 0);
			GIO_control(writeChan, IOM_CHAN_RESET, 0);
	//#######################################################
	
			SEM_pend(&usbMassStorageResetComplete, SYS_FOREVER);
			retVal = C5509_USB_REQUEST_SEND_ACK;
		}
		else          
			//invalid parameters so ignore command
			retVal = C5509_USB_REQUEST_STALL;
	}
    else if(setupPacket->bmRequestType == 0xA1 && setupPacket->bRequest == GET_MAX_LUN)
    {
    	//GET_MAX_LUN: command received
    	//multiple LUNs not supported so stall this command
    	retVal = C5509_USB_REQUEST_SEND_LUN;
    	//if multiple LUNs supported then send 1 byte on control Endpoint
    	//indicating the number of LUNs supported and set retVal to C5509_USB_REQUEST_DATA_OUT
    }    	
    //else if()                                    
    /**********************************************
    //extend functionality here for more requests
    ***********************************************/
	else
	{
   		retVal = handler();    /* call the default setup event handler */
    }             
    
	return retVal;
}


/*
 *  USB device configuration.
 */
C5509_USB_DeviceConfig dapDeviceConfig = {
    &deviceDescriptor[0],
    &stringDescriptorLangId[0],
    &stringDescriptor[0],
    dapEvtCb,
    dapSetupEvtCb
};



#define MAXPKTLEN 64  /* max USB transfer length in bytes */

/*
 *  USB endpoint descriptors
 *  The following are endpoint descriptors for USB interface 0 alternate set 0.
 */
static C5509_USB_EndptDesc endPtDesc[] =
{
    /*
     *  bulk endpoint descriptor - endpt2 OUT 
     */
    {
        0x0000,    
        (C5509_USB_DESCRIPTOR_ENDPT<<8) | 7,    /* bLength = 07h, bDescriptorType */
        0x0202,    /* bEndpointAddress = 02h (2 OUT), bmAttributes = 02h (bulk) */
        MAXPKTLEN, /* wMaxPacketSize = 64 bytes */
        0x00,      /* bInterval */
    },
    /*
     *  bulk endpoint descriptor - endpt2 IN 
     */
    {
        0x0000,    
        (C5509_USB_DESCRIPTOR_ENDPT<<8) | 7,   /* bLength = 07h, bDescriptorType */
        0x0282,    /* bEndpointAddress = 82h (2 IN), bmAttributes = 02h (bulk) */
        MAXPKTLEN, /* wMaxPacketSize */
        0x00       /* bInterval */
    }
};

/*
 * Determine number of IOM channels needed for this configuration.
 */
#define NUMCHANS (sizeof(endPtDesc) / sizeof(C5509_USB_EndptDesc)) 

/*
 *  USB endpoint link list used to describe the configuration to the PC Host.
 */
static USB_DataStruct endptDescLink[NUMCHANS] = {    
    {
        7, (Uint16 *)&endPtDesc[0], &endptDescLink[1]
    },
    {
        7, (Uint16 *)&endPtDesc[1], NULL
    }
};

/* 
 *  IOM channel object array. 
 */
static C5509_USB_ChanObj chans[NUMCHANS]; 

/*
 *  USB driver endpoint configuration array.
 *  Used to initialize the mini-driver and underlying USB CSL.
 *  Note: Endpoint number, transfer size and type need to match the
 *   above endpoint descriptors. 
 */
static C5509_USB_EpConfig endptsConfig[NUMCHANS] = {

    /* 
     * EP #2 OUT, BULK transfer type, max transfer size, OR'd event mask=EOT 
     */
    {
        &chans[0], USB_OUT_EP2, USB_BULK, MAXPKTLEN, USB_EVENT_EOT
    },
    /* 
     * EP #2 IN, BULK transfer type, max transfer size, OR'd event mask=EOT
     */
    {
        &chans[1], USB_IN_EP2, USB_BULK, MAXPKTLEN, USB_EVENT_EOT
    }
};




/*
 *  Configuration descriptor. Used by host to determine the configuration.
 */
static Uint16 configurationDescriptor[] = {
    0x0000,    /* field for xfer_byte_cnt - used by the data */
               /* transfer API, not an integral part of descriptor */
    (C5509_USB_DESCRIPTOR_CONFIG<<8) | 9,    /* bLength, bDescriptorType */
    (18 + (NUMCHANS * 7)),      /* wTotalLength = 9 + 9 + 7 * NUMCHANS */
    0x0101,    /* bNumInterfaces = 1, bConfigurationValue = 1 */
    0x8003,    /* iConfiguration, bmAttributes = bus pwr, no rwu */
    125          /* bMaxPower = 125, 2mA units = 250mA max*/
};


/*
 *  Interface Descriptor
 */
static Uint16 usbIfc0Alt0Descriptor[] =  {  /* interface 0 alt_set = 0 */

    0x0000,    /* field for xfer_byte_cnt - used by the data */
               /* transfer API, not an integral part of descriptor */
    (C5509_USB_DESCRIPTOR_INTRFC << 8) | 9,    /* bLength, bDescriptorType */
    0x0000,    /* bInterfaceNumber = 0, bAlternateSetting = 0 */
    (0x08 << 8) | NUMCHANS,    /* bNumEndpoints = NUMCHANS, bInterfaceClass = 08h (i.e. Mass Storage Class) */
    0x5006,    /* bInterfaceSubClass = 06h (SCSI command set), bInterfaceProtocol = 50h (Bulk Only Transport)*/
    0x04       /* iInterface = index in string descriptor */
};


/*
 * Ifc 0, Alt 0 endpoint link list
 */
static USB_DataStruct usbIfc0Alt0DescLink[] = {     /* Interface Descriptor */
    9,
    (Uint16 *)&usbIfc0Alt0Descriptor[0],  
    &endptDescLink[0]
};


/*
 * USB configuration and interface(s) link list.
 */
static USB_DataStruct configDescLink[] = {     
    9,
    (Uint16 *)&configurationDescriptor[0],   
    &usbIfc0Alt0DescLink[0]
};


/*
 *  USB interface config used by iom driver's devParams.
 */
C5509_USB_IfcConfig dapIfcConfig = {
    NUMCHANS,              /* total number of configured endpoints */
    &configDescLink[0],  /* USB config and interface descriptor list */
    &endptsConfig[0]     /* endpoint configuration array */
};


/*
 *  ======== usbDevParams ========
 *  The usbDevParams structure is used in the USB initialization function
 *  to initialize the usb device.
 *  The usb initialization function and devParams are set in the
 *  DSP/BIOS configuration under Input/Output -> Device drivers -> User defined devices
 */
C5509_USB_DevParams usbDevParams = {
    C5509_USB_VERSION_1,         /* version number 1 */
    C5509_USB_IER0MASKDEFAULT,   /* ier0mask=1 mask self(USB) intr */
    C5509_USB_IER1MASKDEFAULT,   /* ier1mask=1         "           */
    C5509_USB_INCLK12MHZ,        /* inclk, input clock is 12 Mhz */
    C5509_USB_PLLDIVDEFAULT,     /* plldiv, PLL divide value = 0 */
    C5509_USB_PSOFTMRCNTDEFAULT, /* pSofTmrCnt = 128 */
    &dapDeviceConfig,             /* USB device configuration */
    &dapIfcConfig                 /* USB interface endpoints configuration */
};
