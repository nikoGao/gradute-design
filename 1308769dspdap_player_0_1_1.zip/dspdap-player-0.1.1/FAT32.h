/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: FAT32.h,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#ifndef _FAT32_H_
#define _FAT32_H_

#include "types.h"

typedef struct
{
// Filesystem globals
UI16 bytes_per_sector;	//16-bit
UI8 sectors_per_cluster;	//8-bit
UI16 num_reserved_sectors;	//16-bit
UI8 num_FATs;		//8-bit
UI32 FAT_size32;		//32-bit
UI32 root_begin_cluster;		//32-bit
UI16 signature;			//16-bit
UI32 cluster_begin_lba;
UI32 fat_begin_lba;
UI32 root_dir_lba;
} FAT;


//--------------ATTRIBUTE BYTE DEFINATIONS---------------------
#define		ATTR_READ_ONLY	0x01
#define		ATTR_HIDDEN		0x02
#define		ATTR_SYSTEM		0x04
#define		ATTR_VOLID		0x08
#define		ATTR_DIR		0x10
#define		ATTR_ARCHIVE	0x20
#define		ATTR_LFN		0x0F	//indicates Long filename entry
#define 	ATTR_LFN_MSK	0x3F	//ATTR_READ_ONLY|ATTR_HIDDEN|ATTR_SYSTEM|ATTR_VOLID|ATTR_DIR|ATTR_ARCHIVE

typedef struct
{
	UI8 Name[13];	//8 for filename, 3 for extension and 1 for NULL terminator
	
	UI8 Attr;	//MSB of 6th word
	
	UI8 CreTimeTenth;	//Millisecond stamp at file creation time
	UI8 NTRes;		//should be ignored
	
	UI16 CreTime;	//creation time
	UI16 CreDate;	//creation date
	UI16 LastAccessDate;	//last accessed date
	
	UI32 FirstCluster;	//higher 16-bits of 1st cluster number.
	UI16 WriteTime;		//time of last write
	UI16 WriteDate;		//time of last date
	
	UI32 FileSize;
	
} DIR_ENTRY;


#define LAST_LONG_ENTRY_MASK 0x40
typedef struct
{
	UI8 Ordinal;		//order of LFN entry. 
	UI8 Name[14];	//13 + 1 for NULL terminator.
	UI8 Attr;
	UI8 Checksum;
} LFN_ENTRY;

extern FAT FAT32;

UI8 Get8BitWord(UI* buffer, int byteOffset);
UI16 Get16BitWord(UI* buffer, int byteOffset);
UI32 Get32BitWord(UI* buffer, int byteOffset);
UI32 FAT32_GetStartLBAofCluster(UI32 cluster_num);
int FAT32_GetFAT32Details();
UI32 FAT32_FindNextCluster(UI32 currentCluster);
void GetDirEntryFromBuffer(UI16* recordBuf, DIR_ENTRY *pDirEntry);
void GetLfnEntryFromBuffer(UI16* recordBuf, LFN_ENTRY *pLfn);


#endif /*_FAT32_H_*/
