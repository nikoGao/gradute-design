/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: usb_debug.h,v 1.3 2007/06/06 12:04:05 Roger Exp $
 */

//#define USB_DEBUG	/* enables USB debug functions */

//#define	WAVE_DEBUG	/* enables WAVE dump mode in which output is dumped as a wave file over USB*/

#ifdef WAVE_DEBUG
	#define USB_DEBUG
#endif

#if defined(WAVE_DEBUG) && !defined(USB_DEBUG)
 #error "USB_DEBUG must be enabled for WAVE debug mode"
#endif

#ifdef USB_DEBUG

#ifndef WAVE_DEBUG

void usb_print_str(char *str);
void usb_print_int(int x);
void usb_print_long(long x);
#define usb_dump_buffer(a, b)	usb_dump((a), (b))
#define usb_dump_wave(a, b);

#else

#define usb_print_str(a)	
#define usb_print_int(a)	
#define usb_print_long(a)
#define usb_dump_buffer(a, b)
#define usb_dump_wave(a, b)		usb_dump((a), (b))

#endif /* WAVE_DEBUG*/

#else

//define NULL MACROS
#define usb_print_str(a)	
#define usb_print_int(a)	
#define usb_print_long(a)	
#define usb_dump_buffer(a, b)
#define usb_dump_wave(a, b)

#endif



