/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: file.h,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

#include "types.h"
#include "FAT32.h"

// Global Structures
typedef struct  
{
UI32 startCluster;
UI32 fileSize;

UI32 currentCluster;	//indicates which cluster is currently being read from.
UI32 currentSectorInCluster;	//indicates which sector in the cluster is being read from
								//will always be >= 0 and <FAT32.sectors_per_cluster
								
UI32 byteNum;		//indicates number of bytes read.
char feof;	//indicates end of file if non zero.
}FILE;


int GetTotalDirLevelsInPath(const char *path);
void SplitFilePath(const char *FullPath, char *DirPath, char *FileName);
int GetDirStringFromPath(const char *pathStr, int levelreq, char *dirStr);
void RemoveTrailingSpaces(const char* source, char *dest);
int CompareFileNames(char* name1, char* name2);
void Get8_3Filename(char* sfn, char* filename);
FILE *fopen_cluster(UI32 startCluster);
int GetMatchingRecord(UI32 dirCluster, char* nameToFind, DIR_ENTRY *pDirEntry);
UI32 fopen_DIR(char* dirPath);
FILE *fopen(char* fullPath);
int fread_sector(FILE *fp, void* buffer, int* pBytesRead);
void fclose(FILE *fp);
int fread_3sectors(FILE *fp, unsigned int* buffer, int* pBytesRead);
int fast_fread_sector(FILE *fp, void* buffer, int* pBytesRead);
void fast_fread_terminate();
int GetTotalFilesInDirectory(char *directoryPath);
int GetFilenameInDirectory(char *directoryPath, int fileOffset, char *filename);
