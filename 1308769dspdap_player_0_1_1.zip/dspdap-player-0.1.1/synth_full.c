/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * based on
 *
 * libmad - MPEG audio decoder library
 * Copyright (C) 2000-2001 Robert Leslie <rob@mars.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: synth_full.c,v 1.3 2007/06/06 12:04:29 Roger Exp $
 */

/*
 * An optional optimization called here the Subband Synthesis Optimization
 * (SSO) improves the performance of subband synthesis at the expense of
 * accuracy.
 *
 * The idea is to simplify 32x32->64-bit multiplication to 32x32->32 such
 * that extra scaling and rounding are not necessary. This often allows the
 * compiler to use faster 32-bit multiply-accumulate instructions instead of
 * explicit 64-bit multiply, shift, and add instructions.
 *
 * SSO works like this: a full 32x32->64-bit multiply of two mad_fixed_t
 * values requires the result to be right-shifted 28 bits to be properly
 * scaled to the same fixed-point format. Right shifts can be applied at any
 * time to either operand or to the result, so the optimization involves
 * careful placement of these shifts to minimize the loss of accuracy.
 *
 * First, a 14-bit shift is applied with rounding at compile-time to the D[]
 * table of coefficients for the subband synthesis window. This only loses 2
 * bits of accuracy because the lower 12 bits are always zero. A second
 * 12-bit shift occurs after the DCT calculation. This loses 12 bits of
 * accuracy. Finally, a third 2-bit shift occurs just before the sample is
 * saved in the PCM buffer. 14 + 12 + 2 == 28 bits.
 */


/*
	I have modified the synth algorithm so that it works a
	lot faster on a 16-bit fixed point DSP.
	I have used 16x16-bit multiplies in synth_full_asm(),
	however dct32_asm() still uses 32x32-bit multiplies.
	In dct32() the input 32-bit sbsamples are multiplied 
	with 32-bit cosine terms to generate a 32-bit result
	using mad_f_mul().
		I observed that the sbsamples are within +1.999/-2.000
	range and so these 32-bit results are rounded to 16-bit Q1.14 format.
	and stored in synth->filter
		I found that the original D[] vector (from the standard)
	has maximum value of approx +/- 1.2  . So I divided the D[] vector
	coefficients by 2 to get it it purely in fractional form so that
	it can be represented in Q15 format.
		The synth() routine then multiplies the Q1.14 filter values
	with the Q15 D[] table values to get a Q29 result..
*/

#include "mad.h"
#include "playercfg.h"


#  if MAD_F_FRACBITS != 28
#   error "MAD_F_FRACBITS must be 28 to use OPT_SSO" MAD_F_FRACBITS
#  endif
#  define OPT_MUL(x, y)	((long)((long)(x)*(long)(y)))
#  define ML0(hi, lo, x, y)	((lo)  = OPT_MUL((x) , (y)))
#  define MLA(hi, lo, x, y)	((lo) += OPT_MUL((x) , (y)))
#  define MLN(hi, lo)		((lo)  = -(lo))
#  define MLZ(hi, lo)		((void) (hi), (mad_fixed_t) (lo))

// in DCT32 we converted and stored filter samples as Q1.14 format. 
// we converted D table coefficents in Q.15 format.
// so result of Q1.14 x Q.15 is Q.29 format and is purely fractional.
// i.e. no integer part. So 3 MSB bits denote sign and we can use 3rd MSB
// bit as sign and left shift the PCM sample by 2 to get max volume.

#if (PCM_PRECISION > 16)
    //32-bit PCM sample
	#define SHIFT(x) ((x) << 2)
#else
	#define SHIFT(x) ((x) >> 14)	//to get 16-bit sample we right shift by 16
									//but since we also need to left shift by 2 to get
									//proper PCM value, we simply right shift by 14
	/* Actually we need to scale up the samples by 2 to compensate for the division by 2 of the
	   D table coefficients. This works fine but produces audible clicks due to clipping in some cases.
	   Hence we do not provide this left shift for now 
	*/

#endif //(PCM_PRECISION > 16)


extern short int g_synth_filtera[2][2][16][8];	/* polyphase filterbank outputs */
  					/* [eo][peo][s][v] */
extern short int g_synth_filterb[2][2][16][8];
extern unsigned int g_synth_phase;			/* current processing phase */
extern mad_fixed_t g_sbsample[2][18][32];  

extern short int const D[17][32];

PCM_SAMPLE (*pg_pcm_samples)[576];	//pointer to pcm buffer pcm[2][576]

/*
 * NAME:	synth->full()
 * DESCRIPTION:	perform full frequency PCM synthesis
 */
int synth_full_asm(unsigned int nch, unsigned int ns)
{
  unsigned int phase, ch, s, sb, pe, po;
  PCM_SAMPLE *pcm1, *pcm2;
  short int (*filter)[2][2][16][8];
  mad_fixed_t (*sbsample)[18][32];
  short int (*fe)[8], (*fx)[8], (*fo)[8];
  short int const (*Dptr)[32], *ptr;

//  mad_fixed64hi_t hi;
//  mad_fixed64lo_t lo;
  long hi;
  long lo;
  

	//allocate pcm buffer
	//check if pcm output pipe is free
	if(PIP_getWriterNumFrames(&output_pipe)==0)
	{
		//no free frame in output pipe
		return -1;	//exit
	}
	else
	{
		//we have at least 1 free frame in o/p pipe
		PIP_alloc(&output_pipe);
		pg_pcm_samples = PIP_getWriterAddr(&output_pipe);
	}  
  
  for (ch = 0; ch < nch; ++ch) {
    sbsample = &g_sbsample[ch];
//    filter   = &synth->filter[ch];
    phase    = g_synth_phase;
  

    pcm1     = pg_pcm_samples[ch];

	if(ch == 0)
	{
		filter = &g_synth_filtera;	 //left channel
	}
	else
	{
		filter = &g_synth_filterb;	 //right channel
	}

    for (s = 0; s < ns; ++s) {
      dct32((*sbsample)[s], phase >> 1,
	    (*filter)[0][phase & 1], (*filter)[1][phase & 1]);

      pe = phase & ~1;
      po = ((phase - 1) & 0xf) | 1;

      /* calculate 32 samples */

      fe = &(*filter)[0][ phase & 1][0];
      fx = &(*filter)[0][~phase & 1][0];
      fo = &(*filter)[1][~phase & 1][0];

      Dptr = &D[0];

      ptr = *Dptr + po;
      ML0(hi, lo, (*fx)[0], ptr[ 0]);
      MLA(hi, lo, (*fx)[1], ptr[14]);
      MLA(hi, lo, (*fx)[2], ptr[12]);
      MLA(hi, lo, (*fx)[3], ptr[10]);
      MLA(hi, lo, (*fx)[4], ptr[ 8]);
      MLA(hi, lo, (*fx)[5], ptr[ 6]);
      MLA(hi, lo, (*fx)[6], ptr[ 4]);
      MLA(hi, lo, (*fx)[7], ptr[ 2]);
      MLN(hi, lo);

      ptr = *Dptr + pe;
      MLA(hi, lo, (*fe)[0], ptr[ 0]);
      MLA(hi, lo, (*fe)[1], ptr[14]);
      MLA(hi, lo, (*fe)[2], ptr[12]);
      MLA(hi, lo, (*fe)[3], ptr[10]);
      MLA(hi, lo, (*fe)[4], ptr[ 8]);
      MLA(hi, lo, (*fe)[5], ptr[ 6]);
      MLA(hi, lo, (*fe)[6], ptr[ 4]);
      MLA(hi, lo, (*fe)[7], ptr[ 2]);

      *pcm1++ = SHIFT(MLZ(hi, lo));

      pcm2 = pcm1 + 30;

      for (sb = 1; sb < 16; ++sb) {
	++fe;
	++Dptr;

	/* D[32 - sb][i] == -D[sb][31 - i] */

	ptr = *Dptr + po;
	ML0(hi, lo, (*fo)[0], ptr[ 0]);
	MLA(hi, lo, (*fo)[1], ptr[14]);
	MLA(hi, lo, (*fo)[2], ptr[12]);
	MLA(hi, lo, (*fo)[3], ptr[10]);
	MLA(hi, lo, (*fo)[4], ptr[ 8]);
	MLA(hi, lo, (*fo)[5], ptr[ 6]);
	MLA(hi, lo, (*fo)[6], ptr[ 4]);
	MLA(hi, lo, (*fo)[7], ptr[ 2]);
	MLN(hi, lo);

	ptr = *Dptr + pe;
	MLA(hi, lo, (*fe)[7], ptr[ 2]);
	MLA(hi, lo, (*fe)[6], ptr[ 4]);
	MLA(hi, lo, (*fe)[5], ptr[ 6]);
	MLA(hi, lo, (*fe)[4], ptr[ 8]);
	MLA(hi, lo, (*fe)[3], ptr[10]);
	MLA(hi, lo, (*fe)[2], ptr[12]);
	MLA(hi, lo, (*fe)[1], ptr[14]);
	MLA(hi, lo, (*fe)[0], ptr[ 0]);

	*pcm1++ = SHIFT(MLZ(hi, lo));

	ptr = *Dptr - pe;

	lo = 0;
	MLA(hi, lo, (*fe)[0], ptr[31 - 16]);
	MLA(hi, lo, (*fe)[1], ptr[31 - 14]);
	MLA(hi, lo, (*fe)[2], ptr[31 - 12]);
	MLA(hi, lo, (*fe)[3], ptr[31 - 10]);
	MLA(hi, lo, (*fe)[4], ptr[31 -  8]);
	MLA(hi, lo, (*fe)[5], ptr[31 -  6]);
	MLA(hi, lo, (*fe)[6], ptr[31 -  4]);
	MLA(hi, lo, (*fe)[7], ptr[31 -  2]);

	ptr = *Dptr - po;
	MLA(hi, lo, (*fo)[7], ptr[31 -  2]);
	MLA(hi, lo, (*fo)[6], ptr[31 -  4]);
	MLA(hi, lo, (*fo)[5], ptr[31 -  6]);
	MLA(hi, lo, (*fo)[4], ptr[31 -  8]);
	MLA(hi, lo, (*fo)[3], ptr[31 - 10]);
	MLA(hi, lo, (*fo)[2], ptr[31 - 12]);
	MLA(hi, lo, (*fo)[1], ptr[31 - 14]);
	MLA(hi, lo, (*fo)[0], ptr[31 - 16]);

	*pcm2-- = SHIFT(MLZ(hi, lo));

	++fo;
      }

      ++Dptr;

      ptr = *Dptr + po;
      ML0(hi, lo, (*fo)[0], ptr[ 0]);
      MLA(hi, lo, (*fo)[1], ptr[14]);
      MLA(hi, lo, (*fo)[2], ptr[12]);
      MLA(hi, lo, (*fo)[3], ptr[10]);
      MLA(hi, lo, (*fo)[4], ptr[ 8]);
      MLA(hi, lo, (*fo)[5], ptr[ 6]);
      MLA(hi, lo, (*fo)[6], ptr[ 4]);
      MLA(hi, lo, (*fo)[7], ptr[ 2]);


      *pcm1 = SHIFT(-MLZ(hi, lo));
      pcm1 += 16;

      phase = (phase + 1) % 16;

    } //end for( s...

  }//end for( ch...

  //output pipe filled so pack it up
  PIP_put(&output_pipe);
  return 0;	//success
}
