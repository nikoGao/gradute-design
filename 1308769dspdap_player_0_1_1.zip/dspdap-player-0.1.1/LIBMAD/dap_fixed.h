/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: dap_fixed.h,v 1.2 2007/06/05 11:57:31 Roger Exp $
 */

#ifndef LIBMAD_DAP_FIXED_H
#define LIBMAD_DAP_FIXED_H

typedef signed long dap_fixed_t;
//typedef signed long mad_fixed_t;

#define DAP_F_FRACBITS 26

/*
;dap_f_mul(x, y)	((((x) + (1L << 9)) >> 10) *  (((y) + (1L << 15)) >> 16))
;NOTE: increasing right shift of 1st operand degrades decoded audio 
;		quality
;NOTE: while changing this routine make appropriate changes
;	   to the code where 2nd operand in 0x8000000>>2
;	add	#200h,a
;	sfta	a,-10,b
;	dld	*ar1,a
;	add	b,9,a
*/
//USE the one below for best quality.
#   define dap_f_mul(x, y)	((((x) + (1L << 9)) >> 10) *  (((y) + (1L << 15)) >> 16))

//NOTE: increasing right shift of 1st operand degrades decoded audio 
//		quality

# define dap_f_todouble(x)	((double)  \
				 ((x) / (double) (1L << DAP_F_FRACBITS)))

//#  define DAP_F(x)		((dap_fixed_t) ((x)>>2))
//USE the one below for best quality.
#  define DAP_F(x)		((dap_fixed_t) (((x)+ (1L<<1)) >> 2))


#endif
