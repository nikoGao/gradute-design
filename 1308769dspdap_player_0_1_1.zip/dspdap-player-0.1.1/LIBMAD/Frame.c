/*
 * libmad - MPEG audio decoder library
 * Copyright (C) 2000-2001 Robert Leslie
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: Frame.c,v 1.1.1.1 2007/06/05 11:21:13 Roger Exp $
 */

# include "global.h"

# include "bit.h"
# include "stream.h"
# include "frame.h"
# include "timer.h"
//# include "layer12.h"
# include "layer3.h"

struct mad_header g_header;		/* MPEG audio header */
mad_fixed_t g_sbsample[2][18][32];	/* synthesis subband filter samples */  
mad_fixed_t g_overlap[2][32][18];	/* Layer III block overlap data */

static
unsigned long bitrate_table[3][15] = {
  /* MPEG-1 */
  { 0,  32000,  64000,  96000, 128000, 160000, 192000, 224000,  /* Layer I   */
       256000, 288000, 320000, 352000, 384000, 416000, 448000 },
  { 0,  32000,  48000,  56000,  64000,  80000,  96000, 112000,  /* Layer II  */
       128000, 160000, 192000, 224000, 256000, 320000, 384000 },
  { 0,  32000,  40000,  48000,  56000,  64000,  80000,  96000,  /* Layer III */
       112000, 128000, 160000, 192000, 224000, 256000, 320000 },

};

static
unsigned int samplerate_table[3] = { 44100, 48000, 32000 };

/*
static
int (*const decoder_table[3])(struct mad_stream *, struct mad_frame *) = {
  mad_layer_I,
  mad_layer_II,
  mad_layer_III
};
*/

/*
 * NAME:	g_header.init()
 * DESCRIPTION:	initialize header struct
 */
void mad_header_init()
{
  g_header.layer          = 0;
  g_header.mode           = 0;
  g_header.mode_extension = 0;
  g_header.emphasis       = 0;

  g_header.bitrate        = 0;
  g_header.samplerate     = 0;

  g_header.crc_check      = 0;
  g_header.crc_target     = 0;

  g_header.flags          = 0;
  g_header.private_bits   = 0;

  g_header.duration       = mad_timer_zero;
}

/*
 * NAME:	frame->init()
 * DESCRIPTION:	initialize frame struct
 */
void mad_frame_init()
{
  mad_header_init();

  mad_frame_mute();
}

/*
 * NAME:	frame->finish()
 * DESCRIPTION:	deallocate any dynamic memory associated with frame
 */
void mad_frame_finish()
{
  mad_header_finish();
}

/*
 * NAME:	decode_header()
 * DESCRIPTION:	read header data and following CRC word
 */
static
int decode_header()
{
  unsigned int index;

  g_header.flags        = 0;
  g_header.private_bits = 0;

  /* header() */

  /* syncword */
  mad_bit_skip(&stream->ptr, 12);

  /* ID */
  if (mad_bit_read(&stream->ptr, 1) == 0)
  {
	  //ID = 0 means Low Sampling Freq. (LSF) extension.
//    g_header.flags |= MAD_FLAG_LSF_EXT;
	  //i have removed support for LSF extension.
	  stream->error = MAD_ERROR_LOSTSYNC;
	  return -1;
  }

  /* layer */
  g_header.layer = 4 - mad_bit_read(&stream->ptr, 2);

  if (g_header.layer != 3) 
  {
	  //removed support for Layer 1 and Layer 2.
    stream->error = MAD_ERROR_BADLAYER;
    return -1;
  }

  /* protection_bit */
  if (mad_bit_read(&stream->ptr, 1) == 0) {
    g_header.flags    |= MAD_FLAG_PROTECTION;
    g_header.crc_check = mad_bit_crc(stream->ptr, 16, 0xffff);
  }

  /* bitrate_index */
  index = mad_bit_read(&stream->ptr, 4);

  if (index == 15) {
    stream->error = MAD_ERROR_BADBITRATE;
    return -1;
  }

  g_header.bitrate = bitrate_table[g_header.layer - 1][index];

  /* sampling_frequency */
  index = mad_bit_read(&stream->ptr, 2);

  if (index == 3) {
    stream->error = MAD_ERROR_BADSAMPLERATE;
    return -1;
  }

  g_header.samplerate = samplerate_table[index];

  /* padding_bit */
  if (mad_bit_read(&stream->ptr, 1))
    g_header.flags |= MAD_FLAG_PADDING;

  /* private_bit */
  if (mad_bit_read(&stream->ptr, 1))
    g_header.private_bits |= MAD_PRIVATE_HEADER;

  /* mode -> 0 = stereo, 1 = JS, 2 = dual ch, 3 = single ch.*/
  g_header.mode = 3 - mad_bit_read(&stream->ptr, 2);

  /* mode_extension */
  //Intensity stereo and/or Mid-Side stereo
  g_header.mode_extension = mad_bit_read(&stream->ptr, 2);

  /* copyright */
  if (mad_bit_read(&stream->ptr, 1))
    g_header.flags |= MAD_FLAG_COPYRIGHT;

  /* original/copy */
  if (mad_bit_read(&stream->ptr, 1))
    g_header.flags |= MAD_FLAG_ORIGINAL;

  /* emphasis */
  g_header.emphasis = mad_bit_read(&stream->ptr, 2);

  if (g_header.emphasis == 2) {
    stream->error = MAD_ERROR_BADEMPHASIS;
    return -1;
  }

  /* crc_check */
  if (g_header.flags & MAD_FLAG_PROTECTION)
    g_header.crc_target = mad_bit_read(&stream->ptr, 16);
	//get the 16-bit CRC checksum.

  return 0;
}

/*
 * NAME:	free_bitrate()
 * DESCRIPTION:	attempt to discover the bitstream's free bitrate
 */
static
int free_bitrate()
{
  struct mad_bitptr keep_ptr;
  unsigned long rate = 0;
  unsigned int pad_slot, slots_per_frame;
  const unsigned char  *ptr = 0;

  keep_ptr = stream->ptr;

  pad_slot = (g_header.flags & MAD_FLAG_PADDING) ? 1 : 0;

  slots_per_frame = 144;

  while (mad_stream_sync(stream) == 0) {
    struct mad_header peek_header;
	
	peek_header = g_header;

    if (decode_header() == 0 &&
	peek_header.layer == g_header.layer &&
	peek_header.samplerate == g_header.samplerate) {
      unsigned int N;

      ptr = mad_bit_nextbyte(&stream->ptr);

      N = ptr - stream->this_frame;

      if (g_header.layer == MAD_LAYER_I) {
	rate = (unsigned long) g_header.samplerate *
	  (N - 4 * pad_slot + 4) / 48 / 1000;
      }
      else {
	rate = (unsigned long) g_header.samplerate *
	  (N - pad_slot + 1) / slots_per_frame / 1000;
      }

      if (rate >= 8)
	break;
    }

    mad_bit_skip(&stream->ptr, 8);
  }

  stream->ptr = keep_ptr;

  if (rate < 8 || (g_header.layer == MAD_LAYER_III && rate > 640)) {
    stream->error = MAD_ERROR_LOSTSYNC;
    return -1;
  }

  stream->freerate = rate * 1000;

# if 0 && defined(DEBUG)
//  fprintf(stderr, "free bitrate == %lu\n", stream->freerate);
# endif

  return 0;
}

/*
 * NAME:	g_header.decode()
 * DESCRIPTION:	read the next frame header from the stream
 */
int mad_header_decode()
{
  const unsigned char *ptr, *end;
  unsigned int pad_slot, N;

  ptr = stream->next_frame;
  end = stream->bufend;

  if (ptr == 0) {
    stream->error = MAD_ERROR_BUFPTR;
    goto fail;
  }

  /* stream skip */
  if (stream->skiplen) {
    if (!stream->sync)
      ptr = stream->this_frame;

    if (end - ptr < stream->skiplen) {
      stream->skiplen   -= end - ptr;
      stream->next_frame = end;

      stream->error = MAD_ERROR_BUFLEN;
      goto fail;
    }

    ptr += stream->skiplen;
    stream->skiplen = 0;

    stream->sync = 1;
  }

 sync:
  /* synchronize */
  if (stream->sync) {
    if (end - ptr < MAD_BUFFER_GUARD) {
      stream->next_frame = ptr;

      stream->error = MAD_ERROR_BUFLEN;
      goto fail;
    }
    else if (!(ptr[0] == 0xff && (ptr[1] & 0xe0) == 0xe0)) {
      /* mark point where frame sync word was expected */
      stream->this_frame = ptr;
      stream->next_frame = ptr + 1;

      stream->error = MAD_ERROR_LOSTSYNC;
      goto fail;
    }
  }
  else {
  	//stream is out of sync,
    mad_bit_init(&stream->ptr, ptr);

    if (mad_stream_sync(stream) == -1) 
    {
      //did not find any sync word in stream buffer.
      if (end - stream->next_frame >= MAD_BUFFER_GUARD)
      {
			stream->next_frame = end - MAD_BUFFER_GUARD;
	  }
	  
      stream->this_frame = stream->next_frame; //this makes
      									//sure that input func will correctly fill the stream buffer
      
      stream->error = MAD_ERROR_BUFLEN;
      goto fail;
    }

    ptr = mad_bit_nextbyte(&stream->ptr);
  }

  /* begin processing */
  stream->this_frame = ptr;
  stream->next_frame = ptr + 1;  /* possibly bogus sync word */

  mad_bit_init(&stream->ptr, stream->this_frame);

  if (decode_header() == -1)
    goto fail;

  /* calculate frame duration */
//  mad_timer_set(&g_header.duration, 0,
//		32 * MAD_NSBSAMPLES(header), g_header.samplerate);

  /* calculate free bit rate */
  if (g_header.bitrate == 0) {
    if ((stream->freerate == 0 || !stream->sync) &&
	free_bitrate() == -1)
      goto fail;

    g_header.bitrate = stream->freerate;
    g_header.flags  |= MAD_FLAG_FREEFORMAT;
  }

  /* calculate beginning of next frame */
  pad_slot = (g_header.flags & MAD_FLAG_PADDING) ? 1 : 0;

  if (g_header.layer == MAD_LAYER_I)
    N = ((12 * g_header.bitrate / g_header.samplerate) + pad_slot) * 4;
  else {
    unsigned int slots_per_frame;

    slots_per_frame = 144;

    N = (slots_per_frame * g_header.bitrate / g_header.samplerate) + pad_slot;
  }

  /* verify there is enough data left in buffer to decode this frame */
  if (N + MAD_BUFFER_GUARD > end - stream->this_frame) {
    stream->next_frame = stream->this_frame;

    stream->error = MAD_ERROR_BUFLEN;
    goto fail;
  }

  stream->next_frame = stream->this_frame + N;

  if (!stream->sync) {
    /* check that a valid frame header follows this frame */

    ptr = stream->next_frame;
    if (!(ptr[0] == 0xff && (ptr[1] & 0xe0) == 0xe0)) {
      ptr = stream->next_frame = stream->this_frame + 1;
      goto sync;
    }

    stream->sync = 1;
  }

  g_header.flags |= MAD_FLAG_INCOMPLETE;

  return 0;

 fail:
  stream->sync = 0;

  return -1;
}

enum mad_error III_decode(struct sideinfo *si, unsigned int nch);
extern struct sideinfo si;
extern int g_granule_pending;
/*
 * NAME:	frame->decode()
 * DESCRIPTION:	decode a single frame from a bitstream
 */
int mad_frame_decode()
{
  /* header() */    
  /* error_check() */
  if(g_granule_pending == 0)
  {
	  if (!(g_header.flags & MAD_FLAG_INCOMPLETE) &&
    						  mad_header_decode() == -1)
		{
    	goto fail;
    	}

	  /* audio_data() */

	  g_header.flags &= ~MAD_FLAG_INCOMPLETE;
		//calls mad_layer_III() to decode a single frame.
	//  if (decoder_table[g_header.layer - 1](stream, frame) == -1) {
		if(mad_layer_III() == -1) 
		{
    		if (!MAD_RECOVERABLE(stream->error))
      			stream->next_frame = stream->this_frame;

		    goto fail;
  		}
  }
  else
  {
	//granule 1 pending to be processed
	if(mad_layer_III() == -1)
	{
		goto fail;
	}

	//1 complete frame processed.  
  	/* ancillary_data() */
  	if (g_header.layer != MAD_LAYER_III) 
  	{
    	struct mad_bitptr next_frame;
    	mad_bit_init(&next_frame, stream->next_frame);

    	stream->anc_ptr    = stream->ptr;
    	stream->anc_bitlen = mad_bit_length(&stream->ptr, &next_frame);

    	mad_bit_finish(&next_frame);
	}
  }

  return 0;

 fail:
  stream->anc_bitlen = 0;
  return -1;
}

/*
 * NAME:	frame->mute()
 * DESCRIPTION:	zero all subband values so the frame becomes silent
 */
void mad_frame_mute()
{
  unsigned int s, sb;
/*
  for (s = 0; s < 36; ++s) {
    for (sb = 0; sb < 32; ++sb) {
      frame->sbsample[0][s][sb] =
      frame->sbsample[1][s][sb] = 0;
    }
  }
*/
    for (s = 0; s < 18; ++s) 
    {
      for (sb = 0; sb < 32; ++sb) 
      {
		g_overlap[0][sb][s] = g_overlap[1][sb][s] = 0;
      }
    }
}
