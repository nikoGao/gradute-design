/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: Decoder.c,v 1.2 2007/06/05 11:57:31 Roger Exp $
 */


# include <std.h>
# include <pip.h>

# include "global.h"

# include "stream.h"
# include "frame.h"
# include "synth.h"
# include "decoder.h"

struct mad_stream *stream;

struct mad_header *header;

struct mad_synth *synth;

mad_fixed_t g_xr[2][576];


struct mad_stream g_stream;
struct mad_stream *stream = &g_stream;

int g_bad_last_frame = 0; //used indicate when to reset frame
						  //parameters incase a currupted frame
						  //was found.			

int input_func();
extern PIP_Obj output_pipe;

int synth_incomplete = 0;	//will be set to 1 if synth was not performed due
							//to inavailability of pcm buffer
							
int fillme = 1;		//flag to indicate to fill bitstream buffer

int synth_full_asm(unsigned int nch, unsigned int ns);

//this function will be run as SWI_decode
void mad_decoder_run()
{
//	usb_print_str("mad_decoder_run");

	if(synth_incomplete)
	{
		//synthesis was not performed in last decode due to unavailability of pcm buffer
		//so try again
		
		//we will get here if decoder decodes much faster than that required by the DAC.
		//so it is a good sign if we get here.
		
		if(mad_synth_frame())
		{
			//synth was still not performed
			return;
		}
		else
		{
			//synth complete
			synth_incomplete = 0;
		}
	}
	
	if(fillme==1)
	{
		//bitstream buffer is short of data
		if(input_func() == 0)
		{
			//success.
			fillme = 0;	//indicate that bitstream buffer is filled
			//clear BUFLEN error flag and continue
			//decoding the frame.
			stream->error &= ~MAD_ERROR_BUFLEN;
		}
		else
		{
			//input_func() did not complete filling the
			//buffer due to inavailability of input data
			//pipe frame.
			return;   //exit SWI_decode
			 //and gibe SWI_data opportunity to fill pipe
		}
	}
	
	//now we have enough bytes in bitstream buffer
	
	//if mad_frame_decode() failed previously it means
	//we did not call PIP_put and
	//still have a free frame at hand so we must
	//not recall PIP_alloc.
	

	  //mad_frame_decode actuallydecodes an MPEG frame
	  //will store the pcm samples in buffer pointed by
	  //pg_pcm_samples.
    if(mad_frame_decode() == -1)
  	{
  		//some error took place
			if (!MAD_RECOVERABLE(stream->error))
				fillme = 1;	//buffer needs to be filled


			if(stream->error == MAD_ERROR_BADCRC)
			{
					if (g_bad_last_frame)
					{
						mad_frame_mute();
					}
					else
					{
						g_bad_last_frame = 1;
					}
				fillme = 1; //buffer needs to be filled
			}
    }
	else
	{
		  //1 frame decoded successfully
	  g_bad_last_frame = 0;
	
	}        

  return;
 //exit SWI_decode;  
}

