/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * based on
 *
 * libmad - MPEG audio decoder library
 * Copyright (C) 2000-2001 Robert Leslie <rob@mars.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: dct32.c,v 1.2 2007/06/05 11:57:31 Roger Exp $
 */

#include "global.h"
#include "fixed.h"

//#  define SHIFT(x)  ( (short int) ( ( (2*(x)) + (1L << 15)) >> 16) )
//#define SHIFT(x)	( (short int) (((x) + (1L <<12))>>13) )	//convert Q3.28 to Q.15
											//assuming Q3.28 has no integer part

//converting to Q.15 results in some overflow so we will convert to Q1.14 instead											
#define SHIFT(x)	( (short int) (((x) + (1L <<13))>>14) )	//convert Q3.28 to Q1.14
		
#  define MUL(x, y)  mad_f_mul((x), (y))

extern mad_fixed_t const costabA[32];

/*
 * NAME:	dct32()
 * DESCRIPTION:	perform fast in[32]->out[32] DCT
 */
void dct32(mad_fixed_t const in[32], unsigned int slot,
	   short int lo[16][8], short int hi[16][8])
{

  mad_fixed_t t[145];
  mad_fixed_t x[32];
/*
  int i;
  const mad_fixed_t *pina,*pinb, *pcostabA;
  mad_fixed_t *px;
  
  pina = &in[0];
  pinb = &in[31];
  pcostabA = &costabA[0];
  px = x;
  
  for(i=0 ; i<16 ; i++)
  {
	  *px++ = *pina + *pinb;
	  *px++ = MUL( (*pina - *pinb), *pcostabA );
	  pina++;
	  pinb--;
	  pcostabA++;
  }
*/

  x[0]   = in[0]  + in[31];
  x[1]   = MUL(in[0]  - in[31], costabA[1]);

  x[2]   = in[1]  + in[30];  
  x[3]   = MUL(in[1]  - in[30], costabA[3]);

  x[4]  = in[2]  + in[29];  
  x[5]  = MUL(in[2]  - in[29], costabA[5]);

  x[6]  = in[3]  + in[28];  
  x[7]  = MUL(in[3]  - in[28], costabA[7]);

  x[8]  = in[4]  + in[27];  
  x[9]  = MUL(in[4]  - in[27], costabA[9]);

  x[10]  = in[5]  + in[26];  
  x[11]  = MUL(in[5]  - in[26], costabA[11]);

  x[12]  = in[6]  + in[25];  
  x[13]  = MUL(in[6]  - in[25], costabA[13]);

  x[14]  = in[7]  + in[24];  
  x[15]  = MUL(in[7]  - in[24], costabA[15]);

  x[16]  = in[8]  + in[23];  
  x[17]  = MUL(in[8]  - in[23], costabA[17]);

  x[18]  = in[9]  + in[22];  
  x[19]  = MUL(in[9]  - in[22], costabA[19]);

  x[20]  = in[10] + in[21];  
  x[21]  = MUL(in[10] - in[21], costabA[21]);

  x[22]  = in[11] + in[20];  
  x[23]  = MUL(in[11] - in[20], costabA[23]);

  x[24]  = in[12] + in[19];  
  x[25]  = MUL(in[12] - in[19], costabA[25]);

  x[26]  = in[13] + in[18];  
  x[27]  = MUL(in[13] - in[18], costabA[27]);

  x[28]  = in[14] + in[17];  
  x[29]  = MUL(in[14] - in[17], costabA[29]);

  x[30]  = in[15] + in[16];  
  x[31]  = MUL(in[15] - in[16], costabA[31]);


  t[9]  = x[1] + x[31];
  t[27]  = MUL(x[1] - x[31], costabA[2]);

  t[1]  = x[0]  + x[30];
  t[18]  = MUL(x[0]  - x[30],  costabA[2]);

  t[10]  = x[15] + x[17];
  t[28]  = MUL(x[15] - x[17], costabA[30]);

  t[2]  = x[14]  + x[16];
  t[19]  = MUL(x[14]  - x[16],  costabA[30]);

  t[11]  = x[7] + x[25];
  t[29]  = MUL(x[7] - x[25], costabA[14]);

  t[3]  = x[6]  + x[24];
  t[20]  = MUL(x[6]  - x[24],  costabA[14]);

  t[12]  = x[9] + x[23];
  t[30]  = MUL(x[9] - x[23], costabA[18]);

  t[4]  = x[8]  + x[22];
  t[21]  = MUL(x[8]  - x[22],  costabA[18]);

  t[13]  = x[3] + x[29];
  t[31]  = MUL(x[3] - x[29], costabA[6]);

  t[5]  = x[2]  + x[28];
  t[22]  = MUL(x[2]  - x[28],  costabA[6]);

  t[14]  = x[13] + x[19];
  t[32]  = MUL(x[13] - x[19], costabA[26]);

  t[6]  = x[12] + x[18];
  t[23]  = MUL(x[12] - x[18], costabA[26]);

  t[15]  = x[5] + x[27];
  t[33]  = MUL(x[5] - x[27], costabA[10]);

  t[7]  = x[4] + x[26];
  t[24]  = MUL(x[4] - x[26], costabA[10]);

  t[16]  = x[11] + x[21];
  t[34]  = MUL(x[11] - x[21], costabA[22]);

  t[8]  = x[10] + x[20];
  t[25]  = MUL(x[10] - x[20], costabA[22]);



  t[37]  = t[1] + t[2];  
  t[57]  = MUL(t[1] - t[2], costabA[4]);
  t[38]  = t[3] + t[4];  
  t[58]  = MUL(t[3] - t[4], costabA[28]);
  t[39]  = t[5] + t[6];  
  t[59]  = MUL(t[5] - t[6], costabA[12]);
  t[40]  = t[7] + t[8];  
  t[60]  = MUL(t[7] - t[8], costabA[20]);
  t[41]  = t[9] + t[10];  
  t[62]  = MUL(t[9] - t[10], costabA[4]);
  t[42]  = t[11] + t[12];  
  t[63]  = MUL(t[11] - t[12], costabA[28]);
  t[43]  = t[13] + t[14];  
  t[64]  = MUL(t[13] - t[14], costabA[12]);
  t[44]  = t[15] + t[16];  
  t[65]  = MUL(t[15] - t[16], costabA[20]);

  t[46]  = t[18] + t[19];  
  t[68] = MUL(t[18] - t[19], costabA[4]);
  t[47]  = t[20] + t[21];  
  t[69] = MUL(t[20] - t[21], costabA[28]);
  t[48]  = t[22] + t[23]; 
  t[70] = MUL(t[22] - t[23], costabA[12]);
  t[49]  = t[24] + t[25];  
  t[71] = MUL(t[24] - t[25], costabA[20]);

  t[51]  = t[27] + t[28];  
  t[74] = MUL(t[27] - t[28], costabA[4]);
  t[52]  = t[29] + t[30];  
  t[75] = MUL(t[29] - t[30], costabA[28]);
  t[53]  = t[31] + t[32];  
  t[76] = MUL(t[31] - t[32], costabA[12]);
  t[54]  = t[33] + t[34];  
  t[77] = MUL(t[33] - t[34], costabA[20]);

  t[81] = t[37]  + t[38];
  t[82] = t[39]  + t[40];

  /*  0 */ hi[15][slot] = SHIFT(t[81] + t[82]);
  /* 16 */ lo[ 0][slot] = SHIFT(MUL(t[81] - t[82], costabA[16]));

  t[83] = t[41]  + t[42];
  t[84] = t[43]  + t[44];

  t[0]  = t[83] + t[84];

  /*  1 */ hi[14][slot] = SHIFT(t[0]);

  t[86] = t[46]  + t[47];
  t[87] = t[48]  + t[49];

  t[26]  = t[86] + t[87];

  /*  2 */ hi[13][slot] = SHIFT(t[26]);

  t[89] = t[51]  + t[52];
  t[90] = t[53]  + t[54];

  t[35]  = t[89] + t[90];

  t[17]  = (t[35] * 2) - t[0];

  /*  3 */ hi[12][slot] = SHIFT(t[17]);

  t[93] = t[57]  + t[58];
  t[94] = t[59]  + t[60];

  t[61]  = t[93] + t[94];

  /*  4 */ hi[11][slot] = SHIFT(t[61]);

  t[96] = t[62]  + t[63];
  t[97] = t[64]  + t[65];

  t[66]  = t[96] + t[97];

  t[36]  = (t[66] * 2) - t[17];

  /*  5 */ hi[10][slot] = SHIFT(t[36]);

  t[100] = t[68] + t[69];
  t[101] = t[70] + t[71];

  t[72] = t[100] + t[101];

  t[50]  = (t[72] * 2) - t[26];

  /*  6 */ hi[ 9][slot] = SHIFT(t[50]);

  t[104] = t[74] + t[75];
  t[105] = t[76] + t[77];

  t[78] = t[104] + t[105];

  t[55]  = (t[78] * 2) - t[35];

  t[45]  = (t[55] * 2) - t[36];
//----------------------------------------
  /*  7 */ hi[ 8][slot] = SHIFT(t[45]);

  t[109] = MUL(t[37] - t[38], costabA[8]);
  t[110] = MUL(t[39] - t[40], costabA[24]);
  t[111] = t[109] + t[110];

  /*  8 */ hi[ 7][slot] = SHIFT(t[111]);
  /* 24 */ lo[ 8][slot] =
	     SHIFT((MUL(t[109] - t[110], costabA[16]) * 2) - t[111]);

  t[112] = MUL(t[41] - t[42], costabA[8]);
  t[113] = MUL(t[43] - t[44], costabA[24]);
  t[114] = t[112] + t[113];

  t[56]  = (t[114] * 2) - t[45];

  /*  9 */ hi[ 6][slot] = SHIFT(t[56]);

  t[116] = MUL(t[46] - t[47], costabA[8]);
  t[117] = MUL(t[48] - t[49], costabA[24]);
  t[118] = t[116] + t[117];

  t[73] = (t[118] * 2) - t[50];

  /* 10 */ hi[ 5][slot] = SHIFT(t[73]);

  t[120] = MUL(t[51] - t[52], costabA[8]);
  t[121] = MUL(t[53] - t[54], costabA[24]);
  t[122] = t[120] + t[121];

  t[79] = (t[122] * 2) - t[55];

  t[67]  = (t[79] * 2) - t[56];

  /* 11 */ hi[ 4][slot] = SHIFT(t[67]);

  t[125] = MUL(t[57] - t[58], costabA[8]);
  t[126] = MUL(t[59] - t[60], costabA[24]);
  t[127] = t[125] + t[126];

  t[95] = (t[127] * 2) - t[61];

  /* 12 */ hi[ 3][slot] = SHIFT(t[95]);

  t[128] = (MUL(t[93] - t[94], costabA[16]) * 2) - t[95];

  /* 20 */ lo[ 4][slot] = SHIFT(t[128]);
  /* 28 */ lo[12][slot] =
	     SHIFT((((MUL(t[125] - t[126], costabA[16]) * 2) - t[127]) * 2) - t[128]);

  t[129] = MUL(t[62] - t[63], costabA[8]);
  t[130] = MUL(t[64] - t[65], costabA[24]);
  t[131] = t[129] + t[130];

  t[98] = (t[131] * 2) - t[66];

  t[80] = (t[98] * 2) - t[67];

  /* 13 */ hi[ 2][slot] = SHIFT(t[80]);

  t[132] = (MUL(t[96] - t[97], costabA[16]) * 2) - t[98];

  t[134] = MUL(t[68] - t[69], costabA[8]);
  t[135] = MUL(t[70] - t[71], costabA[24]);
  t[136] = t[134] + t[135];

  t[102] = (t[136] * 2) - t[72];

  t[88] = (t[102] * 2) - t[73];

  /* 14 */ hi[ 1][slot] = SHIFT(t[88]);

  t[103] = (MUL(t[86] - t[87], costabA[16]) * 2) - t[88];

  /* 18 */ lo[ 2][slot] = SHIFT(t[103]);

  t[137] = (MUL(t[100] - t[101], costabA[16]) * 2) - t[102];

  t[119] = (t[137] * 2) - t[103];

//----------------------------------------

  /* 22 */ lo[ 6][slot] = SHIFT(t[119]);

  t[138] = (((MUL(t[116] - t[117], costabA[16]) * 2) - t[118]) * 2) - t[119];

  /* 26 */ lo[10][slot] = SHIFT(t[138]);
  /* 30 */ lo[14][slot] =
	     SHIFT((((((MUL(t[134] - t[135], costabA[16]) * 2) -
		       t[136]) * 2) - t[137]) * 2) - t[138]);

  t[139] = MUL(t[74] - t[75], costabA[8]);
  t[140] = MUL(t[76] - t[77], costabA[24]);
  t[141] = t[139] + t[140];

  t[106] = (t[141] * 2) - t[78];

  t[91] = (t[106] * 2) - t[79];

  t[107] = (MUL(t[89] - t[90], costabA[16]) * 2) - t[91];

  t[85] = (t[91] * 2) - t[80];

  /* 15 */ hi[ 0][slot] = SHIFT(t[85]);

  t[92] = (MUL(t[83] - t[84], costabA[16]) * 2) - t[85];

  /* 17 */ lo[ 1][slot] = SHIFT(t[92]);

  t[99] = (t[107] * 2) - t[92];

  /* 19 */ lo[ 3][slot] = SHIFT(t[99]);

  t[108] = (t[132] * 2) - t[99];

  /* 21 */ lo[ 5][slot] = SHIFT(t[108]);

  t[142] = (MUL(t[104] - t[105], costabA[16]) * 2) - t[106];

  t[123] = (t[142] * 2) - t[107];

  t[115] = (t[123] * 2) - t[108];

  /* 23 */ lo[ 7][slot] = SHIFT(t[115]);

  t[124] = (((MUL(t[112] - t[113], costabA[16]) * 2) - t[114]) * 2) - t[115];

  /* 25 */ lo[ 9][slot] = SHIFT(t[124]);

  t[143] = (((MUL(t[120] - t[121], costabA[16]) * 2) - t[122]) * 2) - t[123];

  t[133] = (t[143] * 2) - t[124];

  /* 27 */ lo[11][slot] = SHIFT(t[133]);

  t[144] = (((((MUL(t[129] - t[130], costabA[16]) * 2) -
	     t[131]) * 2) - t[132]) * 2) - t[133];

  /* 29 */ lo[13][slot] = SHIFT(t[144]);
  /* 31 */ lo[15][slot] =
	     SHIFT((((((((MUL(t[139] - t[140], costabA[16]) * 2) -
			 t[141]) * 2) - t[142]) * 2) - t[143]) * 2) - t[144]);

  /*
   * Totals:
   *  80 multiplies
   *  80 additions
   * 119 subtractions
   *  49 shifts (not counting SSO)
   */
}
