/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: imdct_l.c,v 1.2 2007/06/05 11:57:31 Roger Exp $
 */

#include "fixed.h"
#include "dap_fixed.h"


extern mad_fixed_t  window_l[36];
extern mad_fixed_t  window_s[12];


//note : recalculate all DAP_F constant values below. (They have not
//		 been rounded but truncated..so there is scope to increase accuracy).

/*
#define cos_PI9		MAD_F(0xf08fb21)
#define cos_2PI9	MAD_F(0xc41b7d1)
#define cos_4PI9	MAD_F(0x2C74350)
*/

#define cos_PI9		DAP_F(0xf08fb21)
#define cos_2PI9	DAP_F(0xc41b7d1)
#define cos_4PI9	DAP_F(0x2C74350)

/*
#define sin0 0x2c74350
#define sin1 0x8000000
#define sin2 0xc41b7d1
#define sin3 0xf08fb21
*/


#define sin0 DAP_F(0x2c74350)
#define sin1 DAP_F(0x8000000)
#define sin2 DAP_F(0xc41b7d1)
#define sin3 DAP_F(0xf08fb21)


void IMDCT_9pt (dap_fixed_t in9pt[9], dap_fixed_t out9pt[9])
{
  int i;
  dap_fixed_t odd[4], even_idct[5], odd_idct[4];
  dap_fixed_t t0, t1, t2;

//5pt
{
  t0 = dap_f_mul(in9pt[6], DAP_F(0x08000000)) + in9pt[0];

  t1 = in9pt[0] - in9pt[6];           

  t2 = in9pt[2] - in9pt[4] - in9pt[8];

	even_idct[0] = t0 + dap_f_mul( in9pt[2] , cos_PI9) + dap_f_mul( in9pt[4] , cos_2PI9) + dap_f_mul( in9pt[8] , cos_4PI9);
  
	even_idct[1] = dap_f_mul( t2 , DAP_F(0x08000000) ) + t1;

	even_idct[2] = t0 - dap_f_mul(in9pt[2] , cos_4PI9) - dap_f_mul( in9pt[4] , cos_PI9) + dap_f_mul( in9pt[8] , cos_2PI9);
  
	even_idct[3] = t0 - dap_f_mul(in9pt[2] , cos_2PI9) + dap_f_mul(in9pt[4] , cos_4PI9) - dap_f_mul(in9pt[8] , cos_PI9);

    even_idct[4] = t1 - t2;             
}

  odd[0] = in9pt[1];
  for (i = 1; i < 4; i++) {
    odd[i] = in9pt[2*i-1] + in9pt[2*i+1]; // 3 flop 
  }

//4pt
{
  t0 = dap_f_mul(odd[3], DAP_F(0x08000000)) + odd[0];

  t1 = odd[1] - odd[2];

  odd_idct[0] = t0 + dap_f_mul( odd[1] , cos_PI9 ) + dap_f_mul( odd[2] , cos_2PI9 );

  odd_idct[1] = dap_f_mul(t1, DAP_F(0x08000000)) + odd[0] - odd[3]; 

  odd_idct[2] = t0 - dap_f_mul(odd[1] , cos_4PI9) - dap_f_mul(odd[2] , cos_PI9);

  odd_idct[3] = t0 - dap_f_mul(odd[1] , cos_2PI9) + dap_f_mul(odd[2] , cos_4PI9);

}


  /* Adjust for non power of 2 IDCT */
    odd_idct[0] +=  dap_f_mul( in9pt[7] , sin0 );

	odd_idct[1] += -dap_f_mul( in9pt[7] , sin1 );

	odd_idct[2] +=  dap_f_mul( in9pt[7] , sin2 );

	odd_idct[3] += -dap_f_mul( in9pt[7] , sin3 );
  
  /* Post-Twiddle */
	odd_idct[0] = dap_f_mul( odd_idct[0] , DAP_F(0x81f97fd) );

	odd_idct[1] = dap_f_mul( odd_idct[1] , DAP_F(0x93cd3a3) );

	odd_idct[2] = dap_f_mul( odd_idct[2] , DAP_F(0xc721f55) );

	odd_idct[3] = dap_f_mul( odd_idct[3] , DAP_F(0x1763F390) );

  for (i = 0; i < 4; i++) {
    out9pt[i] = even_idct[i] + odd_idct[i]; /* Total 4 flop */
  }

  out9pt[4] = even_idct[4];
  
  for (i = 5; i < 9; i++) {
    out9pt[i] = even_idct[8-i] - odd_idct[8-i]; /* Total 4 flop */
  }

  /* Total: 63 flop */

  return;
  
}

//only 81 mad_f_muls
void IMDCT_Long (mad_fixed_t invec[18], mad_fixed_t outvec[36])
{
  int i;
  dap_fixed_t H[18], h[18], even[9], odd[9], even_idct[9], odd_idct[9];

//  mad_fixed_t invec[18];
/*
  //convert mad_fixed_t to dap_fixed_t
  for(i=0 ; i<18 ; i++)
  {
	  invec[i] = inx[i] >> 2;
  }
*/
  H[0] = invec[0];

  for (i = 1; i < 18; i++) {
    H[i] = invec[i-1] + invec[i]; /* 17 flop */
  }


  for (i = 0; i < 9; i++) {
    even[i] = H[i*2];
  }

  IMDCT_9pt (even, even_idct);   /* 63 flop */
    
  odd[0] = H[1];
  for (i = 1; i < 9; i++) {
    odd[i] = H[i*2-1] + H[i*2+1];   /* Total 8 flop */
  }

  IMDCT_9pt (odd, odd_idct);  /* 63 flop */

  /* Post-Twiddle */
/*  for (i = 0; i < 9; i++) {
    odd_idct[i] *= POST_TWIDDLE (i, 18.0); // Total 9 flop 
  }*/
  {
	  odd_idct[0] = dap_f_mul( odd_idct[0] , DAP_F(0x807d2b2) );
	  odd_idct[1] = dap_f_mul( odd_idct[1] , DAP_F(0x8483ee1) );
	  odd_idct[2] = dap_f_mul( odd_idct[2] , DAP_F(0x8d3b7cd) );
	  odd_idct[3] = dap_f_mul( odd_idct[3] , DAP_F(0x9c42578) );
	  odd_idct[4] = dap_f_mul( odd_idct[4] , DAP_F(0xb504f33) );
	  odd_idct[5] = dap_f_mul( odd_idct[5] , DAP_F(0xdf2943c) );
	  odd_idct[6] = dap_f_mul( odd_idct[6] , DAP_F(0x12edfb18) );
	  odd_idct[7] = dap_f_mul( odd_idct[7] , DAP_F(0x1ee8dd47) );
	  odd_idct[8] = dap_f_mul( odd_idct[8] , DAP_F(0x5bca2a2c) );
  }


  for (i = 0; i < 9; i++) {
    h[i] = even_idct[i] + odd_idct[i]; /* Total 9 flop */
  }

  for (i = 9; i < 18; i++) {
    h[i] = even_idct[17-i] - odd_idct[17-i]; /* Total 9 flop */
  }

/*
  for (i = 0; i < 18; i++) {
    h[i] *= POST_TWIDDLE (i, 36.0); // 18 flop
  }
*/
//	(1.0 / (2.0 * cos ((2*i+1) * (PI / (72)))))
  {
	  h[0] = dap_f_mul( h[0] , DAP_F(0x801f37b) );
	  h[1] = dap_f_mul( h[1] , DAP_F(0x811ac10) );
	  h[2] = dap_f_mul( h[2] , DAP_F(0x831b975) );
	  h[3] = dap_f_mul( h[3] , DAP_F(0x863633d) );
	  h[4] = dap_f_mul( h[4] , DAP_F(0x8a8bd3e) );
	  h[5] = dap_f_mul( h[5] , DAP_F(0x904e0d4) );
	  h[6] = dap_f_mul( h[6] , DAP_F(0x97c4a8a) );
	  h[7] = dap_f_mul( h[7] , DAP_F(0xa157290) );
	  h[8] = dap_f_mul( h[8] , DAP_F(0xad9c9ae) );
	  h[9] = dap_f_mul( h[9] , DAP_F(0xbd76c67) );
	  h[10] = dap_f_mul( h[10] , DAP_F(0xd243537) );
	  h[11] = dap_f_mul( h[11] , DAP_F(0xee3a753) );
	  h[12] = dap_f_mul( h[12] , DAP_F(0x11535056) );
	  h[13] = dap_f_mul( h[13] , DAP_F(0x14e7ae91) );
	  h[14] = dap_f_mul( h[14] , DAP_F(0x1a9aa4bd) );
	  h[15] = dap_f_mul( h[15] , DAP_F(0x24f63937) );
	  h[16] = dap_f_mul( h[16] , DAP_F(0x3d4a5662) );
	  h[17] = dap_f_mul( h[17] , DAP_F(0xb7679970) );
  }
  /* Total: 17+63+8+63+9+9+9+18 = 196 flop */

  /* Rearrange the 18 values from the IDCT to the output vector */
  outvec[0]  =  h[9];
  outvec[1]  =  h[10];
  outvec[2]  =  h[11];
  outvec[3]  =  h[12];
  outvec[4]  =  h[13];
  outvec[5]  =  h[14];
  outvec[6]  =  h[15];
  outvec[7]  =  h[16];
  outvec[8]  =  h[17];

  outvec[9]  = -h[17];
  outvec[10] = -h[16];
  outvec[11] = -h[15];
  outvec[12] = -h[14];
  outvec[13] = -h[13];
  outvec[14] = -h[12];
  outvec[15] = -h[11];
  outvec[16] = -h[10];
  outvec[17] = -h[9];

  outvec[18] = -h[8];
  outvec[19] = -h[7];
  outvec[20] = -h[6];
  outvec[21] = -h[5];
  outvec[22] = -h[4];
  outvec[23] = -h[3];
  outvec[24] = -h[2];
  outvec[25] = -h[1];
  outvec[26] = -h[0];

  outvec[27] = -h[0];
  outvec[28] = -h[1];
  outvec[29] = -h[2];
  outvec[30] = -h[3];
  outvec[31] = -h[4];
  outvec[32] = -h[5];
  outvec[33] = -h[6];
  outvec[34] = -h[7];
  outvec[35] = -h[8];

  //convert dap_fixed_t to mad_fixed_t
/*
  for(i=0 ; i<36 ; i++)
  {
	  outvec[i] = outvec[i] << 2;
  }
*/
  return;

}


/*
 * NAME:	III_imdct_l()
 * DESCRIPTION:	perform IMDCT and windowing for long blocks
 */
void III_imdct_l_asm(mad_fixed_t  X[18], mad_fixed_t z[36],
		 unsigned int block_type)
{
  unsigned int i;

  /* IMDCT */

//  imdct36(X, z);
  IMDCT_Long(X , z);

  /*windowing */
  if(block_type == 0) 
  {
  //case 0:  /* normal window */
    for (i = 0; i < 36; i++) {
		z[i] = fast_mad_f_mul(z[i], window_l[i]);
//      z[i + 0] = fast_mad_f_mul(z[i + 0], window_l[i + 0]);
//      z[i + 1] = fast_mad_f_mul(z[i + 1], window_l[i + 1]);
//      z[i + 2] = fast_mad_f_mul(z[i + 2], window_l[i + 2]);
//      z[i + 3] = fast_mad_f_mul(z[i + 3], window_l[i + 3]);
    }
  }
  else if(block_type == 1)
  {
  //case 1:  /* start block */
    for (i =  0; i < 18; ++i) 
	{
		z[i] = fast_mad_f_mul(z[i], window_l[i]);
	}
    /*  (i = 18; i < 24; ++i) z[i] unchanged */
    for (i = 24; i < 30; ++i)
	{
		z[i] = fast_mad_f_mul(z[i], window_s[i - 18]);
	}

    for (i = 30; i < 36; ++i)
	{
		z[i] = 0;
	}
  }
  else if(block_type == 3)
  {
  //case 3:  /* stop block */
    for (i =  0; i <  6; ++i)
	{
		z[i] = 0;
	}
    for (i =  6; i < 12; ++i)
	{
		z[i] = fast_mad_f_mul(z[i], window_s[i - 6]);
	}
    /*  (i = 12; i < 18; ++i) z[i] unchanged */
    for (i = 18; i < 36; ++i)
	{
		z[i] = fast_mad_f_mul(z[i], window_l[i]);
	}
  }
}
