/*
 * libmad - MPEG audio decoder library
 * Copyright (C) 2000-2001 Robert Leslie
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: Synth.c,v 1.2 2007/06/06 12:05:28 Roger Exp $
 */

# include "global.h"

# include "fixed.h"
# include "frame.h"
# include "synth.h"

  short int g_synth_filtera[2][2][16][8];	/* polyphase filterbank outputs */
  					/* [eo][peo][s][v] */
  short int g_synth_filterb[2][2][16][8];
  unsigned int g_synth_phase;			/* current processing phase */

  unsigned int g_pcm_samplerate;		/* sampling frequency (Hz) */
  unsigned short g_pcm_channels;		/* number of channels */
  unsigned short g_pcm_length;		/* number of samples per channel */
  
/*
 * NAME:	synth->init()
 * DESCRIPTION:	initialize synth struct
 */
void mad_synth_init()
{
  mad_synth_mute();

  g_synth_phase = 0;

  g_pcm_samplerate = 0;
  g_pcm_channels   = 0;
  g_pcm_length     = 0;
}

/*
 * NAME:	synth->mute()
 * DESCRIPTION:	zero all polyphase filterbank values, resetting synthesis
 */
void mad_synth_mute()
{
  unsigned int s, v;

    for (s = 0; s < 16; ++s) {
      for (v = 0; v < 8; ++v) {
	g_synth_filtera[0][0][s][v] = g_synth_filtera[0][1][s][v] =
	g_synth_filtera[1][0][s][v] = g_synth_filtera[1][1][s][v] = 0;

	g_synth_filterb[0][0][s][v] = g_synth_filterb[0][1][s][v] =
	g_synth_filterb[1][0][s][v] = g_synth_filterb[1][1][s][v] = 0;
      }
    }
}

/*
 * An optional optimization called here the Subband Synthesis Optimization
 * (SSO) improves the performance of subband synthesis at the expense of
 * accuracy.
 *
 * The idea is to simplify 32x32->64-bit multiplication to 32x32->32 such
 * that extra scaling and rounding are not necessary. This often allows the
 * compiler to use faster 32-bit multiply-accumulate instructions instead of
 * explicit 64-bit multiply, shift, and add instructions.
 *
 * SSO works like this: a full 32x32->64-bit multiply of two mad_fixed_t
 * values requires the result to be right-shifted 28 bits to be properly
 * scaled to the same fixed-point format. Right shifts can be applied at any
 * time to either operand or to the result, so the optimization involves
 * careful placement of these shifts to minimize the loss of accuracy.
 *
 * First, a 14-bit shift is applied with rounding at compile-time to the D[]
 * table of coefficients for the subband synthesis window. This only loses 2
 * bits of accuracy because the lower 12 bits are always zero. A second
 * 12-bit shift occurs after the DCT calculation. This loses 12 bits of
 * accuracy. Finally, a third 2-bit shift occurs just before the sample is
 * saved in the PCM buffer. 14 + 12 + 2 == 28 bits.
 */

/*
	I have modified the synth algorithm so that it works a
	lot faster on a 16-bit fixed point DSP.
	I have used 16x16-bit multiplies in synth_full_asm(),
	however dct32_asm() still uses 32x32-bit multiplies.
	In dct32() the input 32-bit sbsamples are multiplied 
	with 32-bit cosine terms to generate a 32-bit result
	using mad_f_mul().
		I observed that the sbsamples are within +1.999/-2.000
	range and so these 32-bit results are rounded to 16-bit Q1.14 format.
	and stored in synth->filter
		I found that the original D[] vector (from the standard)
	has maximum value of approx +/- 1.2  . So I divided the D[] vector
	coefficients by 2 to get it it purely in fractional form so that
	it can be represented in Q15 format.
		The synth() routine then multiplies the Q1.14 filter values
	with the Q15 D[] table values to get a Q29 result..
*/

/* FPM_DEFAULT without OPT_SSO will actually lose accuracy and performance */

# if defined(FPM_DEFAULT) && !defined(OPT_SSO)
#  define OPT_SSO
# endif

//THIS costable is required for dct32_asm()
mad_fixed_t const costabA[32] =
{
	/* costab[i] = cos(PI / (2 * 32) * i) */
	0,
/*#  define costab[1]*/	MAD_F(0x0ffb10f2)  /* 0.998795456 */,
/*#  define costab[2]*/	MAD_F(0x0fec46d2)  /* 0.995184727 */,
/*#  define costab[3]*/	MAD_F(0x0fd3aac0)  /* 0.989176510 */,
/*#  define costab[4]*/	MAD_F(0x0fb14be8)  /* 0.980785280 */,
/*#  define costab[5]*/	MAD_F(0x0f853f7e)  /* 0.970031253 */,
/*#  define costab[6]*/	MAD_F(0x0f4fa0ab)  /* 0.956940336 */,
/*#  define costab[7]*/	MAD_F(0x0f109082)  /* 0.941544065 */,
/*#  define costab[8]*/	MAD_F(0x0ec835e8)  /* 0.923879533 */,
/*#  define costab[9]*/	MAD_F(0x0e76bd7a)  /* 0.903989293 */,
/*#  define costab[10]*/	MAD_F(0x0e1c5979)  /* 0.881921264 */,
/*#  define costab[11]*/	MAD_F(0x0db941a3)  /* 0.857728610 */,
/*#  define costab[12]*/	MAD_F(0x0d4db315)  /* 0.831469612 */,
/*#  define costab[13]*/	MAD_F(0x0cd9f024)  /* 0.803207531 */,
/*#  define costab[14]*/	MAD_F(0x0c5e4036)  /* 0.773010453 */,
/*#  define costab[15]*/	MAD_F(0x0bdaef91)  /* 0.740951125 */,
/*#  define costab[16]*/	MAD_F(0x0b504f33)  /* 0.707106781 */,
/*#  define costab[17]*/	MAD_F(0x0abeb49a)  /* 0.671558955 */,
/*#  define costab[18]*/	MAD_F(0x0a267993)  /* 0.634393284 */,
/*#  define costab[19]*/	MAD_F(0x0987fbfe)  /* 0.595699304 */,
/*#  define costab[20]*/	MAD_F(0x08e39d9d)  /* 0.555570233 */,
/*#  define costab[21]*/	MAD_F(0x0839c3cd)  /* 0.514102744 */,
/*#  define costab[22]*/	MAD_F(0x078ad74e)  /* 0.471396737 */,
/*#  define costab[23]*/	MAD_F(0x06d74402)  /* 0.427555093 */,
/*#  define costab[24]*/	MAD_F(0x061f78aa)  /* 0.382683432 */,
/*#  define costab[25]*/	MAD_F(0x0563e69d)  /* 0.336889853 */,
/*#  define costab[26]*/	MAD_F(0x04a5018c)  /* 0.290284677 */,
/*#  define costab[27]*/	MAD_F(0x03e33f2f)  /* 0.242980180 */,
/*#  define costab[28]*/	MAD_F(0x031f1708)  /* 0.195090322 */,
/*#  define costab[29]*/	MAD_F(0x0259020e)  /* 0.146730474 */,
/*#  define costab[30]*/	MAD_F(0x01917a6c)  /* 0.098017140 */,
/*#  define costab[31]*/	MAD_F(0x00c8fb30)  /* 0.049067674 */
};


//#  define PRESHIFT(x)		((MAD_F(x) + (1L << 13)) >> 14)
//#  define PRESHIFT(x)		(x)

//convert D table samples from Q.28 to Q.15. To do so we have to right
//shift by 13. But To eliminate integer part from D samples we need to divide
//them by 2. so we give an additional right shift. i.e. we right shift by 14
//instad of 13
#define	PRESHIFT(x)	(((x) + (1L<<13))>>14)

//D table required for dct32_asm()
int const D[17][32] = {
# include "D.dat"
};
       

int synth_full_asm(unsigned int nch, unsigned int ns);
/*
 * NAME:	synth->frame()
 * DESCRIPTION:	perform PCM synthesis of frame subband samples
 */
int mad_synth_frame()
{
  unsigned int nch, ns;

//  void (*synth_frame)(unsigned int, unsigned int);

  nch = MAD_NCHANNELS(g_header);
  ns  = 18;        //number of samples per subband.

  g_pcm_samplerate = g_header.samplerate;
  g_pcm_channels   = nch;
  g_pcm_length     = 32 * ns;

/*
  if (frame->options & MAD_OPTION_HALFSAMPLERATE) {
    synth->pcm.samplerate /= 2;
    synth->pcm.length     /= 2;

    synth_frame = synth_half;
  }
*/
  if(synth_full_asm(nch, ns) != 0)
  {
  	//synth was not performed
  	synth_incomplete = 1;
  	return -1;
  }  
  else
  {
  	//synthesis complete
  	synth_incomplete = 0;
    g_synth_phase = (g_synth_phase + ns) % 16;
    return 0;
  }
}
