/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: externals.h,v 1.2 2007/06/05 11:57:31 Roger Exp $
 */

# ifndef LIBMAD_EXTERNALS_H
# define LIBMAD_EXTERNALS_H

#include "fixed.h"

//extern struct mad_decoder *decoder;
//extern void *data;

extern struct mad_stream *stream;

//extern struct mad_header *header;

extern struct mad_header g_header;		/* MPEG audio header */
extern mad_fixed_t g_sbsample[2][18][32];	/* synthesis subband filter samples */
extern mad_fixed_t g_overlap[2][32][18];	/* Layer III block overlap data */

//extern struct mad_synth *synth;
extern mad_fixed_t g_xr[2][576];

extern int synth_incomplete;

#endif
