/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: CF.h,v 1.2 2007/06/05 11:53:57 Roger Exp $
 */

//#define FULL_EMIF_MODE 1	/* uncomment this if using FULL EMIF mode */

#ifdef FULL_EMIF_MODE
//In EMIF mode A14 is routed to pin A0 and all data
//accesses are word accesses. so addresses below are
//word addresses A23 to A1..keeping in mind that A14 gets out
//on the A0 pin. 
//The 2 in the MS digit is to access external CE0 space
//NOTE: All addresses below are word addresses.
//---------CF card Task File registers-----------
#define DATA_REG 	0x21000
#define FEATURE_REG 0x23000
#define ERROR_REG	0x23000
#define	SECTOR_CNT_REG	0x21001
#define SECTOR_NO_REG	0x23001
#define CYL_LOW_REG		0x21002
#define CYL_HIGH_REG	0x23002
#define	DRIVE_HEAD_REG	0x21003
#define STATUS_REG	0x23003
#define COMMAND_REG	0x23003

//---------CF card control registers--------------
#define ALT_STATUS_REG	0x20803
#define DEV_CTRL_REG	0x20803
#define DRIVE_ADDR_REG	0x22803

#else
//These addresses are defined for AGPIO mode.
//in this mode data placed in AGPIO register gets out on A13-A0 lines
//The 2 in the MS digit is to access external CE0 space

//---------CF card Task File registers-----------
#define DATA_REG 	0x22000
#define FEATURE_REG 0x22001
#define ERROR_REG	0x22001
#define	SECTOR_CNT_REG	0x22002
#define SECTOR_NO_REG	0x22003
#define CYL_LOW_REG		0x22004
#define CYL_HIGH_REG	0x22005
#define	DRIVE_HEAD_REG	0x22006
#define STATUS_REG	0x22007
#define COMMAND_REG	0x22007

//---------CF card control registers--------------
#define ALT_STATUS_REG	0x21006
#define DEV_CTRL_REG	0x21006
#define DRIVE_ADDR_REG	0x21007

#endif /*not FULL_EMIF_MODE*/

//---------ATA commands------------------
#define IDENTIFY_DRIVE_CMD	0xEC
#define READ_SECTORS_CMD	0x20
#define WRITE_SECTORS_CMD	0x30

//---------------------------------------
enum BUSY_STATUS {CF_NOT_BUSY, CF_BUSY};
enum READY_STATUS {CF_NOT_READY, CF_READY};
enum DRQ_STATUS {CF_DRQ_RESET, CF_DRQ_SET};
enum CF_RESULT {CF_FAIL = -1, CF_PASS};


typedef struct CF_BUFFER
{
	int dummy;	//used for IOM packet size
	unsigned int data[256];	//256 words read/write buffer.
} CF_BUFFER;

extern CF_BUFFER cf_buffer;

int CF_IsPresent();
void CF_HardReset();
enum BUSY_STATUS CF_CheckBusyStatus();
enum READY_STATUS CF_CheckReadyStatus();
enum DRQ_STATUS CF_CheckDrqStatus();

void CF_IssueCommand(unsigned long PhysicalSector, unsigned short SectorCount, unsigned short Command);
int CF_IdentifyDrive();
int CF_ReadSector(unsigned long LBA_address, void* buffer);
int CF_WriteSector(unsigned long LBA_address, void* buffer);

int CF_ReadSectors(unsigned long LBA_address, unsigned short num_sectors);
int CF_WriteSectors(unsigned long LBA_address, unsigned short num_sectors);
