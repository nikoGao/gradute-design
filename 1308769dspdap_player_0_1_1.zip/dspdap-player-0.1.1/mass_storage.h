/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: mass_storage.h,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

/* This file implements the USB mass storage Bulk Only Protocol related routines.
 * Roger Quadros
 * 9th April,2005
 */

#define CBW_SIZE 31
#define CSW_SIZE 13

#define CBW_SIGNATURE	0x43425355
#define CSW_SIGNATURE   0x53425355

//CSW status definations
#define COMMAND_PASSED	0x0
#define COMMAND_FAILED	0x1
#define PHASE_ERROR		0x2

//Class specific Setup commands
#define BULK_ONLY_MASS_STORAGE_RESET	0xFF
#define GET_MAX_LUN						0xFE

//sense key definations
#define NO_SENSE 			0
#define RECOVERED_ERROR     0x1
#define NOT_READY           0x2
#define MEDIUM_ERROR		0x3
#define HARDWARE_ERROR		0x4
#define ILLEGAL_REQUEST		0x5
#define UNIT_ATTENTION		0x6
#define DATA_PROTECT		0x7
#define BLANK_CHECK			0x8
#define VENDOR_SPECIFIC		0x9
#define COPY_ABORTED		0xA
#define ABORTED_COMMAND		0xB
#define	VOLUME_OVERFLOW		0xD
#define MISCOMPARE	        0xE

//Additional Sense Code(ASC) and Qualifier(ASCQ) definations

#define NO_ADDITIONAL_SENSE_INFORMATION 0x0	//ASC
#define NO_ADDITIONAL_SENSE_INFORMATION_Q 0x0	//ASCQ

#define INVALID_FIELD_IN_CDB		0x24	//ASC
#define INVALID_FIELD_IN_CDB_Q		0x0		//ASCQ

#define NOT_READY_TO_READY_CHANGE	0x28
#define NOT_READY_TO_READY_CHANGE_Q 0x0

#define INVALID_COMMAND_OPERATION_CODE	0x20
#define INVALID_COMMAND_OPERATION_CODE_Q	0x0

#define UNRECOVERED_READ_ERROR		0x11
#define UNRECOVERED_READ_ERROR_Q		0x0

#define LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE		0x21
#define LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE_Q	0x0

//used internally by ms_get_CBW()
typedef struct CBW_TEMP
{    
	int dummy; 		//1st word reserved for size in IOM packet
	//Signature and Tag have been divided into low and high words for 
	//architecture specific issues.
	int dCBWSignature_low;        //2 bytes
	int dCBWSignature_high;        //2 bytes
	int dCBWTag_low;              //2 bytes
	int dCBWTag_high;              //2 bytes
	int dCBWDataTransferLength_low;  //2 bytes
	int dCBWDataTransferLength_high;  //2 bytes
	int bCBWLUN_bmCBWFlags;	//Higher byte = bCBWLUN : Lower Byte = bmCBWFlags
	int CBWCB_bCBWCBLength;	//Higer byte is 1st byte of CBWCB : Lower byte = bCBWCBLength
	int CBWCB[8];	//remaining 15 bytes of CBWCB
	
	int dummy2[16];	//dummy 32 bytes to recieve a packet of max length 64 bytes.
} CBW_TEMP;

typedef struct CBW
{     
	long dCBWSignature;        //4 bytes
	long dCBWTag;              //4 bytes
	long dCBWDataTransferLength;      //4 bytes
	int	bmCBWFlags;	
	int bCBWLUN;
	int bCBWCBLength;
	char CBWCB[16];		//16 bytes of CBWCB. 1st byte as lower byte, next as higher byte
} CBW;


//used internally by ms_send_CSW()
typedef struct CSW_TEMP
{     
	int dummy;		//1st word reserved for size in an IOM packet.
	//Signature and Tag have been divided into low and high words for 
	//architecture specific issues.	
	int dCSWSignature_low;        //2 bytes
	int dCSWSignature_high;        //2 bytes
	int dCSWTag_low;              //2 bytes
	int dCSWTag_high;              //2 bytes	
	int dCSWDataResidue_low;      //2 bytes
	int dCSWDataResidue_high;      //2 bytes
	int bCSWStatus;			//status byte is in LSByte. MSByte is unused.
} CSW_TEMP;


typedef struct CSW
{     
	long dCSWSignature;        //4 bytes
	long dCSWTag;              //4 bytes
	long dCSWDataResidue;      //4 bytes
	char bCSWStatus;	//status byte is in LSByte. MSByte is unused.
} CSW;


typedef struct FIXED_SENSE_DATA
{
//NOTE: fileds of this structure are arranged specially for
//the C55x DSP so that the values are in the order in which
//bytes are required to be sent out over the USB.
	unsigned int dummy; //1st word reserved for size in IOM packet
	
	unsigned int obsolete:8; //compiler starts filling from the MSB of the word
	unsigned int VALID:1;
	unsigned int RESPONSE_CODE:7;
	
	unsigned int INFORMATION_0:8;
	unsigned int FILEMARK:1;
	unsigned int EOM:1;
	unsigned int ILI:1;
	unsigned int reserved:1;
	unsigned int SENSE_KEY:4;    
	
	unsigned int INFORMATION_2:8;
	unsigned int INFORMATION_1:8;	
	
	unsigned int ADDITIONAL_SENSE_LENGTH:8;
	unsigned int INFORMATION_3:8;
	
	unsigned int COMMAND_SPECIFIC_INF_1:8;
	unsigned int COMMAND_SPECIFIC_INF_0:8;
	
	unsigned int COMMAND_SPECIFIC_INF_3:8;
	unsigned int COMMAND_SPECIFIC_INF_2:8;

	unsigned int ADDITIONAL_SENSE_CODE_QUALIFIER:8;	
	unsigned int ADDITIONAL_SENSE_CODE:8;
	
	unsigned int SKSV:1;
	unsigned int SENSE_KEY_SPECIFIC_0:7;
	unsigned int FIELD_REPLACABLE_UNIT_CODE:8;
	
	unsigned int SENSE_KEY_SPECIFIC_2:8;
	unsigned int SENSE_KEY_SPECIFIC_1:8;
} FIXED_SENSE_DATA;               

#define FIXED_SENSE_DATA_LENGTH	18

typedef struct STANDARD_INQUIRY_DATA
{
//NOTE: fileds of this structure are arranged specially for
//the C55x DSP so that the values are in the order in which
//bytes are required to be sent out over the USB.
	unsigned int dummy; //1st word reserved for size in IOM packet
	
	unsigned int RMB:1;
	unsigned int reserved1:7;
	unsigned int PERIPHERAL_QUALIFIER:3;       
	unsigned int PERIPHERAL_DEVICE_TYPE:5;
	
	unsigned int obsolete1:2;
	unsigned int NORMACA:1;
	unsigned int HISUP:1;
	unsigned int RESPONSE_DATA_FORMAT:4;
	unsigned int VERSION:8;

	unsigned int SCCS:1;
	unsigned int ACC:1;
	unsigned int TPGS:2;
	unsigned int PC:1;
	unsigned int reserved2:2;
	unsigned int PROTECT:1;
	unsigned int ADDITIONAL_LENGTH:8;

	unsigned int obsolete3:2;
	unsigned int WBUS16:1;
	unsigned int SYNC:1;
	unsigned int LINKED:1;
	unsigned int obsolete4:1;
	unsigned int CMDQUE:1;
	unsigned int VS_2:1;
	unsigned int BQUE:1;
	unsigned int ENCSERV:1;
	unsigned int VS_1:1;
	unsigned int MULTIP:1;
	unsigned int MCHNGR:1;
	unsigned int obsolete2:2;
	unsigned int ADDR16:1;
		
	char T10_VENDOR_ID_STRING[4];	//8 bytes of Vendor ID string
	
	char PRODUCT_ID_STRING[8];		//16 bytes of Product ID string
	
	char PRODUCT_REV_STRING[2];	//4 bytes of Product Revision string
	
} STANDARD_INQUIRY_DATA;

#define STANDARD_INQUIRY_DATA_LENGTH	36

typedef struct READ_CAPACITY_10_DATA
{
	int dummy;
	
	unsigned int LBA_2:8;
	unsigned int LBA_3:8;		//MSByte

	unsigned int LBA_0:8;		//LSByte
	unsigned int LBA_1:8;		
    
    unsigned int BLOCK_LENGTH_2:8;
    unsigned int BLOCK_LENGTH_3:8;	//MSByte
	
	unsigned int BLOCK_LENGTH_0:8;	//LSByte
	unsigned int BLOCK_LENGTH_1:8;
	
} READ_CAPACITY_10_DATA;

#define READ_CAPACITY_10_DATA_LENGTH	8

typedef struct MODE_PARAMETER_HEADER
{                       
	int dummy;
	
	unsigned int MEDIUM_TYPE:8;
	unsigned int MODE_DATA_LENGTH:8;
	
	unsigned int BLOCK_DESCRIPTOR_LENGTH:8;
	
	//this is the DEVICE SPECIFIC PARAMETER...see SBC-3 .. mode parameters
	unsigned int WP:1;	//Hardware Write protect.
	unsigned int reserved:2;
	unsigned int DPOFUA:1;
	unsigned int reserved2:4;
	
} MODE_PARAMETER_HEADER;

#define MODE_PARAMETER_HEADER_LENGTH 	4

typedef struct INQUIRY_CMD
{
	unsigned int OPCODE;
	unsigned int EVPD;
	unsigned int PAGE_CODE;
	unsigned int ALLOCATION_LENGTH;
	unsigned int CONTROL;
} INQUIRY_CMD;

int ms_get_CBW(CBW * ptrCBW);
void ms_send_CSW(CSW * ptrCSW);
