/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: mass_storage.c,v 1.2 2007/06/05 11:53:58 Roger Exp $
 */

/* This file implements the USB mass storage Bulk Only Protocol related routines.
 * Roger Quadros
 * 9th April,2005
 */

#include <std.h>
#include <gio.h>
#include <iom.h>
#include <c5509_usb.h>

#include "playercfg.h"
#include "IO.h"
#include "CF.h"
#include "mass_storage.h"
#include "usb_debug.h"

extern GIO_Handle readChan, writeChan; 

//Gets a packet from bus. checks if it's a valid CBW.
//if valid then global CBW object is updated with the new CBW.
//and returns 0 else returns -1.

int ms_get_CBW(CBW * ptrCBW)
{
	Uns requestSize;   
	CBW_TEMP CBW_temp;
	int i,j;
	unsigned long signature;
	unsigned long tlong;
		

   	requestSize = 64;	//max USB packet length in bytes.
   	//we are expecting 31 bytes but we'll ask for more to check if host
   	//has sent a larger packet or no.
	GIO_read(readChan, &CBW_temp, &requestSize);	
	signature = CBW_temp.dCBWSignature_high;
	signature = (signature <<16) | (CBW_temp.dCBWSignature_low & 0xFFFF);

	//check if CBW valid
	//CBW is considered valid if its packet size was CBW_SIZE
	//and signature is valid.
	if( (requestSize == CBW_SIZE) && (signature == CBW_SIGNATURE))
	{
		//valid CBW	
//		usb_print_str("Got Valid CBW");
		//update our global CBW
		ptrCBW->dCBWSignature = signature;
		
		tlong = CBW_temp.dCBWDataTransferLength_high;
		tlong = tlong << 16 | CBW_temp.dCBWDataTransferLength_low & 0xFFFF;
		ptrCBW->dCBWDataTransferLength = tlong;
//		usb_print_long(ptrCBW->dCBWDataTransferLength);

		tlong =	CBW_temp.dCBWTag_high;
		tlong = tlong << 16 | CBW_temp.dCBWTag_low & 0xFFFF;
		ptrCBW->dCBWTag = tlong;	       
//		usb_print_long(ptrCBW->dCBWTag);
		
				
		ptrCBW->bCBWLUN = (CBW_temp.bCBWLUN_bmCBWFlags >> 8) & 0xFF;
//		usb_print_int(ptrCBW->bCBWLUN);
		ptrCBW->bmCBWFlags = CBW_temp.bCBWLUN_bmCBWFlags & 0xFF;
//		usb_print_int(ptrCBW->bmCBWFlags);
		ptrCBW->bCBWCBLength = CBW_temp.CBWCB_bCBWCBLength & 0xFF;
//		usb_print_int(ptrCBW->bCBWCBLength);

		//get 1st byte of CBWCB.
		ptrCBW->CBWCB[0] = (CBW_temp.CBWCB_bCBWCBLength >> 8) & 0xFF;

		//get remaining bytes of CBWCB
		j = 1;		
		for(i=0 ; i<7 ; i++)
		{
			ptrCBW->CBWCB[j++] = CBW_temp.CBWCB[i] & 0xFF;
			ptrCBW->CBWCB[j++] = (CBW_temp.CBWCB[i] >> 8) & 0xFF;
		}
		ptrCBW->CBWCB[j++] = CBW_temp.CBWCB[i] & 0xFF;
/*		
		for(i=0; i<16; i++)
		{
			usb_print_int(ptrCBW->CBWCB[i]);
		}
*/		
		return 0;	//done
	}
	else
	{   
		//invalid CBW
		
		return -1;	//indicate invalid CBW
	}
}


void ms_send_CSW(CSW * ptrCSW)
{
	long tlong;
	CSW_TEMP CSW_temp;           
	Uns requestSize;
	
	//fill CSW_temp as per *ptrCSW
	tlong = ptrCSW->dCSWSignature;
	CSW_temp.dCSWSignature_low = tlong & 0xFFFF;
	CSW_temp.dCSWSignature_high = tlong >> 16 & 0xFFFF;
	
	tlong = ptrCSW->dCSWTag;
	CSW_temp.dCSWTag_low = tlong & 0xFFFF;
	CSW_temp.dCSWTag_high = tlong >> 16 & 0xFFFF;	
	
	tlong = ptrCSW->dCSWDataResidue;
	CSW_temp.dCSWDataResidue_low = tlong & 0xFFFF;
	CSW_temp.dCSWDataResidue_high = tlong >> 16 & 0xFFFF;	
	
	CSW_temp.bCSWStatus = ptrCSW->bCSWStatus;	
	
	requestSize = CSW_SIZE;	//in bytes
	GIO_write(writeChan, &CSW_temp, &requestSize);
}


