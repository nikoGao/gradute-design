/*
 * DSPdap-player - DSP based Digital Audio Player
 * Copyright (C) 2004-2007 Roger Quadros <rogerquads @ yahoo . com>
 * http://dspdap.sourceforge.net
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: usb_debug.c,v 1.3 2007/06/06 12:04:05 Roger Exp $
 */

#include "usb_task.h"
#include "usb_debug.h"

#define DATASIZE    64             /* data size in bytes */

#define USBBUFSIZE (DATASIZE/2 + 1)  /* first word reserved for transfer size */
						//DATASIZE is for no. of bytes..and buffer is of words

#ifdef USB_DEBUG

Uns usbBuf[DATASIZE/2 + 1];	/* first word reserved for transfer size */
//DATASIZE is for no. of bytes..and buffer is of words
#ifndef WAVE_DEBUG
Void usb_print_str(char *str)
{
	Uns requestSize;
	int i,j;
	
	if(!usbConnected)
		return;
			
	if(writeChan == NULL)
		return;

	j = 0;	
	for(i=1; i<=DATASIZE/2 ; i++)
	{
		if(str[j] == 0)
			break;
			
		usbBuf[i] = str[j++];
		
		if(str[j] == 0)
			break;
		
		usbBuf[i] |= (str[j++] << 8);	//Fit in Higher Byte
	}
	
	requestSize = j;	//number of bytes
	GIO_write(writeChan, &usbBuf, &requestSize);
}

Void usb_print_int(int x)
{
	Uns requestSize;

	if(!usbConnected)
		return;
			
	if(writeChan == NULL)
		return;
		
	usbBuf[1] = (x>>8)&0xFF | (x<<8)&0xFF00;	//swap bytes;
	requestSize = 2;	//2 bytes to transfer.
	GIO_write(writeChan, &usbBuf, &requestSize);	
}   

Void usb_print_long(long x)
{
	Uns requestSize;
	int i;

	if(!usbConnected)
		return;		
	if(writeChan == NULL)
		return;
	i = (x>>16) & 0xFFFF;	//MSW
	usbBuf[1] = (i>>8)&0xFF | (i<<8)&0xFF00;	//swap bytes
	
	i = x&0xFFFF;	//LSW
	usbBuf[2] = (i>>8)&0xFF | (i<<8)&0xFF00;		//swap bytes
	
	requestSize = 4;	//4 bytes
	GIO_write(writeChan, &usbBuf, &requestSize);
}    

#endif /* WAVE_DEBUG */

//size in MAUs
Void usb_dump(void *bufptr, int size)
{
	Uns requestSize;
	unsigned int *uiptr;
	int i;
	
	uiptr = (unsigned int *)bufptr;

	if(!usbConnected)
		return;
			
	if(writeChan == NULL)
		return;

	while(size > 0)
	{
		//fill usb buffer and send data
		if(size > DATASIZE/2)
		{
			for(i=1; i<=DATASIZE/2 ; i++)
			{
				usbBuf[i] = *uiptr++;	//usbBuf[0] is not used
			}
			size -= DATASIZE/2;			//DATASIZE/2 words read
			requestSize = DATASIZE;		
			GIO_write(writeChan, &usbBuf, &requestSize);	
		}
		else
		{
			for(i=1; i<=size ; i++)
			{
				usbBuf[i] = *uiptr++;	//usbBuf[0] is not used
			}
			requestSize = size*2;

			GIO_write(writeChan, &usbBuf, &requestSize);	
			//this was the last packet. check if requested size was 64
			//if yes then we need to send a Zero length packet as per USB standards. 
			if(requestSize == 64)
			{
				requestSize = 0;
				GIO_write(writeChan, &usbBuf, &requestSize);	
			}			
			size = 0;
		}
	}
}       
#endif	/*USB_DEBUG*/



